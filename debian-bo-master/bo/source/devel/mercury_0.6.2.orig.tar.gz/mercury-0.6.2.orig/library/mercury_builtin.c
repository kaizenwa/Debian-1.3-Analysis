/*
** Automatically generated from `mercury_builtin.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__mercury_builtin__init
ENDINIT
*/

#include "imp.h"
#include "type_info.h"

Declare_static(mercury____Index___mercury_builtin_term__context_0__ua10000_2_0);
Declare_static(mercury____Index___mercury_builtin_list_1__ua10000_2_0);
Declare_label(mercury____Index___mercury_builtin_list_1__ua10000_2_0_i3);
Declare_static(mercury____Compare___mercury_builtin_base_type_info_1__ua10000_3_0);
Declare_static(mercury____Index___mercury_builtin_base_type_info_1__ua10000_2_0);
Declare_static(mercury____Unify___mercury_builtin_base_type_info_1__ua0_2_0);
Declare_label(mercury____Unify___mercury_builtin_base_type_info_1__ua0_2_0_i1);
Declare_static(mercury____Compare___mercury_builtin_type_info_1__ua10000_3_0);
Declare_static(mercury____Index___mercury_builtin_type_info_1__ua10000_2_0);
Declare_static(mercury____Unify___mercury_builtin_type_info_1__ua0_2_0);
Declare_static(mercury__builtin_type_to_term_pred__ua10000_2_0);
Declare_label(mercury__builtin_type_to_term_pred__ua10000_2_0_i4);
Declare_label(mercury__builtin_type_to_term_pred__ua10000_2_0_i3);
Declare_label(mercury__builtin_type_to_term_pred__ua10000_2_0_i7);
Declare_static(mercury__builtin_term_to_type_pred__ua0_2_0);
Declare_label(mercury__builtin_term_to_type_pred__ua0_2_0_i2);
Declare_label(mercury__builtin_term_to_type_pred__ua0_2_0_i6);
Declare_label(mercury__builtin_term_to_type_pred__ua0_2_0_i8);
Declare_label(mercury__builtin_term_to_type_pred__ua0_2_0_i5);
Declare_label(mercury__builtin_term_to_type_pred__ua0_2_0_i1);
Declare_static(mercury__builtin_compare_pred__ua10000_3_0);
Declare_label(mercury__builtin_compare_pred__ua10000_3_0_i4);
Declare_label(mercury__builtin_compare_pred__ua10000_3_0_i1000);
Declare_static(mercury__builtin_index_pred__ua10000_2_0);
Declare_static(mercury__builtin_unify_pred__ua0_2_0);
Declare_label(mercury__builtin_unify_pred__ua0_2_0_i4);
Declare_label(mercury__builtin_unify_pred__ua0_2_0_i3);
Declare_label(mercury__builtin_unify_pred__ua0_2_0_i9);
Declare_static(mercury__builtin_index_float__ua10000_2_0);
Declare_static(mercury__builtin_index_string__ua10000_2_0);
Declare_static(mercury__f_33_95_95_117_97_49_48_48_48_49_2_0);
Declare_static(mercury__f_33_95_95_117_97_49_48_48_48_48_2_0);
Define_extern_entry(mercury__f_cut_0_0);
Define_extern_entry(mercury__f_cut_2_0);
Define_extern_entry(mercury__f_cut_2_1);
Define_extern_entry(mercury__det_term_to_type_2_0);
Declare_label(mercury__det_term_to_type_2_0_i4);
Declare_label(mercury__det_term_to_type_2_0_i1000);
Define_extern_entry(mercury__builtin_unify_int_2_0);
Declare_label(mercury__builtin_unify_int_2_0_i1);
Define_extern_entry(mercury__builtin_index_int_2_0);
Define_extern_entry(mercury__builtin_compare_int_3_0);
Declare_label(mercury__builtin_compare_int_3_0_i2);
Declare_label(mercury__builtin_compare_int_3_0_i4);
Define_extern_entry(mercury__builtin_term_to_type_int_2_0);
Declare_label(mercury__builtin_term_to_type_int_2_0_i1);
Define_extern_entry(mercury__builtin_type_to_term_int_2_0);
Declare_label(mercury__builtin_type_to_term_int_2_0_i2);
Define_extern_entry(mercury__builtin_unify_character_2_0);
Declare_label(mercury__builtin_unify_character_2_0_i1);
Define_extern_entry(mercury__builtin_index_character_2_0);
Define_extern_entry(mercury__builtin_compare_character_3_0);
Declare_label(mercury__builtin_compare_character_3_0_i2);
Declare_label(mercury__builtin_compare_character_3_0_i3);
Declare_label(mercury__builtin_compare_character_3_0_i4);
Declare_label(mercury__builtin_compare_character_3_0_i6);
Define_extern_entry(mercury__builtin_term_to_type_character_2_0);
Declare_label(mercury__builtin_term_to_type_character_2_0_i5);
Declare_label(mercury__builtin_term_to_type_character_2_0_i1005);
Declare_label(mercury__builtin_term_to_type_character_2_0_i1007);
Define_extern_entry(mercury__builtin_type_to_term_character_2_0);
Declare_label(mercury__builtin_type_to_term_character_2_0_i2);
Declare_label(mercury__builtin_type_to_term_character_2_0_i3);
Define_extern_entry(mercury__builtin_unify_string_2_0);
Declare_label(mercury__builtin_unify_string_2_0_i1);
Define_extern_entry(mercury__builtin_index_string_2_0);
Define_extern_entry(mercury__builtin_compare_string_3_0);
Declare_label(mercury__builtin_compare_string_3_0_i2);
Declare_label(mercury__builtin_compare_string_3_0_i3);
Declare_label(mercury__builtin_compare_string_3_0_i1000);
Define_extern_entry(mercury__builtin_term_to_type_string_2_0);
Declare_label(mercury__builtin_term_to_type_string_2_0_i1);
Define_extern_entry(mercury__builtin_type_to_term_string_2_0);
Declare_label(mercury__builtin_type_to_term_string_2_0_i2);
Define_extern_entry(mercury__builtin_unify_float_2_0);
Declare_label(mercury__builtin_unify_float_2_0_i1);
Define_extern_entry(mercury__builtin_index_float_2_0);
Define_extern_entry(mercury__builtin_compare_float_3_0);
Declare_label(mercury__builtin_compare_float_3_0_i2);
Declare_label(mercury__builtin_compare_float_3_0_i4);
Define_extern_entry(mercury__builtin_term_to_type_float_2_0);
Declare_label(mercury__builtin_term_to_type_float_2_0_i1);
Define_extern_entry(mercury__builtin_type_to_term_float_2_0);
Declare_label(mercury__builtin_type_to_term_float_2_0_i2);
Define_extern_entry(mercury__builtin_unify_pred_2_0);
Define_extern_entry(mercury__builtin_index_pred_2_0);
Define_extern_entry(mercury__builtin_compare_pred_3_0);
Define_extern_entry(mercury__builtin_term_to_type_pred_2_0);
Declare_label(mercury__builtin_term_to_type_pred_2_0_i2);
Declare_label(mercury__builtin_term_to_type_pred_2_0_i1000);
Define_extern_entry(mercury__builtin_type_to_term_pred_2_0);
Define_extern_entry(mercury__unused_0_0);
Declare_label(mercury__unused_0_0_i4);
Declare_label(mercury__unused_0_0_i1000);
Define_extern_entry(mercury__compare_error_0_0);
Declare_label(mercury__compare_error_0_0_i2);
Define_extern_entry(mercury__term__init_var_supply_1_1);
Declare_label(mercury__term__init_var_supply_1_1_i1);
Define_extern_entry(mercury__term__init_var_supply_1_0);
Define_extern_entry(mercury__term__create_var_3_0);
Define_extern_entry(mercury__term__var_to_int_2_0);
Define_extern_entry(mercury__term__context_init_1_0);
Declare_static(mercury__builtin_strcmp_3_0);
Define_extern_entry(mercury____Unify___mercury_builtin__c_pointer_0_0);
Declare_label(mercury____Unify___mercury_builtin__c_pointer_0_0_i1);
Define_extern_entry(mercury____Index___mercury_builtin__c_pointer_0_0);
Define_extern_entry(mercury____Compare___mercury_builtin__c_pointer_0_0);
Define_extern_entry(mercury____Unify___mercury_builtin__comparison_result_0_0);
Declare_label(mercury____Unify___mercury_builtin__comparison_result_0_0_i1);
Define_extern_entry(mercury____Index___mercury_builtin__comparison_result_0_0);
Define_extern_entry(mercury____Compare___mercury_builtin__comparison_result_0_0);
Define_extern_entry(mercury____Unify___mercury_builtin__type_info_1_0);
Define_extern_entry(mercury____Index___mercury_builtin__type_info_1_0);
Define_extern_entry(mercury____Compare___mercury_builtin__type_info_1_0);
Define_extern_entry(mercury____Unify___mercury_builtin__base_type_info_1_0);
Define_extern_entry(mercury____Index___mercury_builtin__base_type_info_1_0);
Define_extern_entry(mercury____Compare___mercury_builtin__base_type_info_1_0);
Define_extern_entry(mercury____Unify___mercury_builtin__term_0_0);
Declare_label(mercury____Unify___mercury_builtin__term_0_0_i5);
Declare_label(mercury____Unify___mercury_builtin__term_0_0_i7);
Declare_label(mercury____Unify___mercury_builtin__term_0_0_i1010);
Declare_label(mercury____Unify___mercury_builtin__term_0_0_i1007);
Declare_label(mercury____Unify___mercury_builtin__term_0_0_i1);
Declare_label(mercury____Unify___mercury_builtin__term_0_0_i1009);
Define_extern_entry(mercury____Index___mercury_builtin__term_0_0);
Declare_label(mercury____Index___mercury_builtin__term_0_0_i3);
Define_extern_entry(mercury____Compare___mercury_builtin__term_0_0);
Declare_label(mercury____Compare___mercury_builtin__term_0_0_i2);
Declare_label(mercury____Compare___mercury_builtin__term_0_0_i3);
Declare_label(mercury____Compare___mercury_builtin__term_0_0_i4);
Declare_label(mercury____Compare___mercury_builtin__term_0_0_i6);
Declare_label(mercury____Compare___mercury_builtin__term_0_0_i15);
Declare_label(mercury____Compare___mercury_builtin__term_0_0_i16);
Declare_label(mercury____Compare___mercury_builtin__term_0_0_i14);
Declare_label(mercury____Compare___mercury_builtin__term_0_0_i21);
Declare_label(mercury____Compare___mercury_builtin__term_0_0_i11);
Declare_label(mercury____Compare___mercury_builtin__term_0_0_i9);
Define_extern_entry(mercury____Unify___mercury_builtin__const_0_0);
Declare_label(mercury____Unify___mercury_builtin__const_0_0_i4);
Declare_label(mercury____Unify___mercury_builtin__const_0_0_i6);
Declare_label(mercury____Unify___mercury_builtin__const_0_0_i8);
Declare_label(mercury____Unify___mercury_builtin__const_0_0_i1);
Define_extern_entry(mercury____Index___mercury_builtin__const_0_0);
Declare_label(mercury____Index___mercury_builtin__const_0_0_i4);
Declare_label(mercury____Index___mercury_builtin__const_0_0_i5);
Declare_label(mercury____Index___mercury_builtin__const_0_0_i6);
Define_extern_entry(mercury____Compare___mercury_builtin__const_0_0);
Declare_label(mercury____Compare___mercury_builtin__const_0_0_i2);
Declare_label(mercury____Compare___mercury_builtin__const_0_0_i3);
Declare_label(mercury____Compare___mercury_builtin__const_0_0_i4);
Declare_label(mercury____Compare___mercury_builtin__const_0_0_i6);
Declare_label(mercury____Compare___mercury_builtin__const_0_0_i12);
Declare_label(mercury____Compare___mercury_builtin__const_0_0_i15);
Declare_label(mercury____Compare___mercury_builtin__const_0_0_i18);
Declare_label(mercury____Compare___mercury_builtin__const_0_0_i1000);
Define_extern_entry(mercury____Unify___mercury_builtin__var_0_0);
Declare_label(mercury____Unify___mercury_builtin__var_0_0_i1);
Define_extern_entry(mercury____Index___mercury_builtin__var_0_0);
Define_extern_entry(mercury____Compare___mercury_builtin__var_0_0);
Define_extern_entry(mercury____Unify___mercury_builtin__var_supply_0_0);
Declare_label(mercury____Unify___mercury_builtin__var_supply_0_0_i1);
Define_extern_entry(mercury____Index___mercury_builtin__var_supply_0_0);
Define_extern_entry(mercury____Compare___mercury_builtin__var_supply_0_0);
Define_extern_entry(mercury____Unify___mercury_builtin__list_1_0);
Declare_label(mercury____Unify___mercury_builtin__list_1_0_i1009);
Declare_label(mercury____Unify___mercury_builtin__list_1_0_i6);
Declare_label(mercury____Unify___mercury_builtin__list_1_0_i1006);
Declare_label(mercury____Unify___mercury_builtin__list_1_0_i1);
Define_extern_entry(mercury____Index___mercury_builtin__list_1_0);
Define_extern_entry(mercury____Compare___mercury_builtin__list_1_0);
Declare_label(mercury____Compare___mercury_builtin__list_1_0_i2);
Declare_label(mercury____Compare___mercury_builtin__list_1_0_i3);
Declare_label(mercury____Compare___mercury_builtin__list_1_0_i4);
Declare_label(mercury____Compare___mercury_builtin__list_1_0_i6);
Declare_label(mercury____Compare___mercury_builtin__list_1_0_i11);
Declare_label(mercury____Compare___mercury_builtin__list_1_0_i16);
Declare_label(mercury____Compare___mercury_builtin__list_1_0_i15);
Declare_label(mercury____Compare___mercury_builtin__list_1_0_i9);
Define_extern_entry(mercury____Unify___mercury_builtin__term__context_0_0);
Declare_label(mercury____Unify___mercury_builtin__term__context_0_0_i1);
Define_extern_entry(mercury____Index___mercury_builtin__term__context_0_0);
Define_extern_entry(mercury____Compare___mercury_builtin__term__context_0_0);
Declare_label(mercury____Compare___mercury_builtin__term__context_0_0_i4);
Declare_label(mercury____Compare___mercury_builtin__term__context_0_0_i3);

Define_extern_entry(mercury__copy_2_0);
Define_extern_entry(mercury__copy_2_1);

BEGIN_MODULE(copy_module)
	init_entry(mercury__copy_2_0);
	init_entry(mercury__copy_2_1);
BEGIN_CODE

Define_entry(mercury__copy_2_0);
Define_entry(mercury__copy_2_1);
#ifdef	COMPACT_ARGS
	r1 = r2;
#else
	r3 = r2;
#endif
	proceed();

END_MODULE

/* Ensure that the initialization code for the above module gets run. */
/*
INIT sys_init_copy_module
*/
void sys_init_copy_module(void); /* suppress gcc -Wmissing-decl warning */
void sys_init_copy_module(void) {
	extern ModuleFunc copy_module;
	copy_module();
}



#ifdef	SHARED_ONE_OR_TWO_CELL_TYPE_INFO


#ifdef  USE_TYPE_LAYOUT

Word * mercury_data___base_type_layout_int_0[] = {
	make_typelayout_for_all_tags(TYPELAYOUT_CONST_TAG, 
		mkbody(TYPELAYOUT_INT_VALUE))
};

Word * mercury_data___base_type_layout_character_0[] = {
	make_typelayout_for_all_tags(TYPELAYOUT_CONST_TAG, 
		mkbody(TYPELAYOUT_CHARACTER_VALUE))
};

Word * mercury_data___base_type_layout_string_0[] = {
	make_typelayout_for_all_tags(TYPELAYOUT_CONST_TAG, 
		mkbody(TYPELAYOUT_STRING_VALUE))
};

Word * mercury_data___base_type_layout_float_0[] = {
	make_typelayout_for_all_tags(TYPELAYOUT_CONST_TAG, 
		mkbody(TYPELAYOUT_FLOAT_VALUE))
};

Word * mercury_data___base_type_layout_pred_0[] = {
	make_typelayout_for_all_tags(TYPELAYOUT_CONST_TAG, 
		mkbody(TYPELAYOUT_PREDICATE_VALUE))
};

#endif

Declare_entry(mercury__builtin_unify_int_2_0);
Declare_entry(mercury__builtin_index_int_2_0);
Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury__builtin_term_to_type_int_2_0);
Declare_entry(mercury__builtin_type_to_term_int_2_0);
Word * mercury_data___base_type_info_int_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__builtin_unify_int_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_index_int_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_compare_int_3_0),
#ifdef USE_TYPE_TO_TERM
	(Word *) (Integer) ENTRY(mercury__builtin_term_to_type_int_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_type_to_term_int_2_0),
#endif
#ifdef  USE_TYPE_LAYOUT
	(Word *) (Integer) mercury_data___base_type_layout_int_0
#endif
};


Declare_entry(mercury__builtin_unify_character_2_0);
Declare_entry(mercury__builtin_index_character_2_0);
Declare_entry(mercury__builtin_compare_character_3_0);
Declare_entry(mercury__builtin_term_to_type_character_2_0);
Declare_entry(mercury__builtin_type_to_term_character_2_0);
Word * mercury_data___base_type_info_character_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__builtin_unify_character_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_index_character_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_compare_character_3_0),
#ifdef USE_TYPE_TO_TERM
	(Word *) (Integer) ENTRY(mercury__builtin_term_to_type_character_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_type_to_term_character_2_0),
#endif
#ifdef  USE_TYPE_LAYOUT
	(Word *) (Integer) mercury_data___base_type_layout_character_0
#endif
};


Declare_entry(mercury__builtin_unify_string_2_0);
Declare_entry(mercury__builtin_index_string_2_0);
Declare_entry(mercury__builtin_compare_string_3_0);
Declare_entry(mercury__builtin_term_to_type_string_2_0);
Declare_entry(mercury__builtin_type_to_term_string_2_0);
Word * mercury_data___base_type_info_string_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__builtin_unify_string_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_index_string_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_compare_string_3_0),
#ifdef USE_TYPE_TO_TERM
	(Word *) (Integer) ENTRY(mercury__builtin_term_to_type_string_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_type_to_term_string_2_0)
#endif
#ifdef  USE_TYPE_LAYOUT
	(Word *) (Integer) mercury_data___base_type_layout_string_0
#endif
};


Declare_entry(mercury__builtin_unify_float_2_0);
Declare_entry(mercury__builtin_index_float_2_0);
Declare_entry(mercury__builtin_compare_float_3_0);
Declare_entry(mercury__builtin_term_to_type_float_2_0);
Declare_entry(mercury__builtin_type_to_term_float_2_0);
Word * mercury_data___base_type_info_float_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__builtin_unify_float_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_index_float_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_compare_float_3_0),
#ifdef USE_TYPE_TO_TERM
	(Word *) (Integer) ENTRY(mercury__builtin_term_to_type_float_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_type_to_term_float_2_0)
#endif
#ifdef  USE_TYPE_LAYOUT
	(Word *) (Integer) mercury_data___base_type_layout_float_0
#endif
};


Declare_entry(mercury__builtin_unify_pred_2_0);
Declare_entry(mercury__builtin_index_pred_2_0);
Declare_entry(mercury__builtin_compare_pred_3_0);
Declare_entry(mercury__builtin_term_to_type_pred_2_0);
Declare_entry(mercury__builtin_type_to_term_pred_2_0);
Word * mercury_data___base_type_info_pred_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__builtin_unify_pred_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_index_pred_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_compare_pred_3_0),
#ifdef USE_TYPE_TO_TERM
	(Word *) (Integer) ENTRY(mercury__builtin_term_to_type_pred_2_0),
	(Word *) (Integer) ENTRY(mercury__builtin_type_to_term_pred_2_0)
#endif
#ifdef  USE_TYPE_LAYOUT
	(Word *) (Integer) mercury_data___base_type_layout_pred_0
#endif
};

#endif


extern Word * mercury_data_mercury_builtin__base_type_layout_base_type_info_1[];
Word * mercury_data_mercury_builtin__base_type_info_base_type_info_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___mercury_builtin__base_type_info_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___mercury_builtin__base_type_info_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mercury_builtin__base_type_info_1_0),
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_layout_base_type_info_1
};

extern Word * mercury_data_mercury_builtin__base_type_layout_c_pointer_0[];
Word * mercury_data_mercury_builtin__base_type_info_c_pointer_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___mercury_builtin__c_pointer_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___mercury_builtin__c_pointer_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mercury_builtin__c_pointer_0_0),
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_layout_c_pointer_0
};

extern Word * mercury_data_mercury_builtin__base_type_layout_comparison_result_0[];
Word * mercury_data_mercury_builtin__base_type_info_comparison_result_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___mercury_builtin__comparison_result_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___mercury_builtin__comparison_result_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mercury_builtin__comparison_result_0_0),
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_layout_comparison_result_0
};

extern Word * mercury_data_mercury_builtin__base_type_layout_const_0[];
Word * mercury_data_mercury_builtin__base_type_info_const_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___mercury_builtin__const_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___mercury_builtin__const_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mercury_builtin__const_0_0),
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_layout_const_0
};

extern Word * mercury_data_mercury_builtin__base_type_layout_list_1[];
Word * mercury_data_mercury_builtin__base_type_info_list_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___mercury_builtin__list_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___mercury_builtin__list_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mercury_builtin__list_1_0),
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_layout_list_1
};

extern Word * mercury_data_mercury_builtin__base_type_layout_term_0[];
Word * mercury_data_mercury_builtin__base_type_info_term_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___mercury_builtin__term_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___mercury_builtin__term_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mercury_builtin__term_0_0),
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_layout_term_0
};

extern Word * mercury_data_mercury_builtin__base_type_layout_term__context_0[];
Word * mercury_data_mercury_builtin__base_type_info_term__context_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___mercury_builtin__term__context_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___mercury_builtin__term__context_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mercury_builtin__term__context_0_0),
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_layout_term__context_0
};

extern Word * mercury_data_mercury_builtin__base_type_layout_type_info_1[];
Word * mercury_data_mercury_builtin__base_type_info_type_info_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___mercury_builtin__type_info_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___mercury_builtin__type_info_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mercury_builtin__type_info_1_0),
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_layout_type_info_1
};

extern Word * mercury_data_mercury_builtin__base_type_layout_var_0[];
Word * mercury_data_mercury_builtin__base_type_info_var_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___mercury_builtin__var_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___mercury_builtin__var_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mercury_builtin__var_0_0),
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_layout_var_0
};

extern Word * mercury_data_mercury_builtin__base_type_layout_var_supply_0[];
Word * mercury_data_mercury_builtin__base_type_info_var_supply_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___mercury_builtin__var_supply_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___mercury_builtin__var_supply_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___mercury_builtin__var_supply_0_0),
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_layout_var_supply_0
};

extern Word * mercury_data_mercury_builtin__common_4[];
Word * mercury_data_mercury_builtin__base_type_layout_var_supply_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4)
};

Word * mercury_data_mercury_builtin__base_type_layout_var_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4)
};

extern Word * mercury_data_mercury_builtin__common_6[];
Word * mercury_data_mercury_builtin__base_type_layout_type_info_1[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_builtin__common_6),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mercury_builtin__common_8[];
Word * mercury_data_mercury_builtin__base_type_layout_term__context_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_builtin__common_8),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mercury_builtin__common_12[];
extern Word * mercury_data_mercury_builtin__common_13[];
Word * mercury_data_mercury_builtin__base_type_layout_term_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_builtin__common_12),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_builtin__common_13),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mercury_builtin__common_14[];
extern Word * mercury_data_mercury_builtin__common_16[];
Word * mercury_data_mercury_builtin__base_type_layout_list_1[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_14),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_builtin__common_16),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_mercury_builtin__common_17[];
extern Word * mercury_data_mercury_builtin__common_18[];
extern Word * mercury_data_mercury_builtin__common_19[];
extern Word * mercury_data_mercury_builtin__common_21[];
Word * mercury_data_mercury_builtin__base_type_layout_const_0[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_builtin__common_17),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_builtin__common_18),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_builtin__common_19),
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_builtin__common_21)
};

extern Word * mercury_data_mercury_builtin__common_22[];
Word * mercury_data_mercury_builtin__base_type_layout_comparison_result_0[] = {
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_22),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_22)
};

Word * mercury_data_mercury_builtin__base_type_layout_c_pointer_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_mercury_builtin__common_4)
};

extern Word * mercury_data_mercury_builtin__common_23[];
Word * mercury_data_mercury_builtin__base_type_layout_base_type_info_1[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_mercury_builtin__common_23),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_mercury_builtin__common_0[] = {
	(Word *) string_const("", 0)
};

Declare_entry(mercury__std_util__semidet_succeed_0_0);
Word * mercury_data_mercury_builtin__common_1[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__std_util__semidet_succeed_0_0)
};

Word * mercury_data_mercury_builtin__common_2[] = {
	(Word *) string_const("", 0),
	(Word *) ((Integer) 0)
};

extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_mercury_builtin__common_3[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_mercury_builtin__common_4[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_3)
};

Word * mercury_data_mercury_builtin__common_5[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_base_type_info_1,
	(Word *) ((Integer) 1)
};

Word * mercury_data_mercury_builtin__common_6[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_5),
	(Word *) string_const("type_info", 9)
};

extern Word * mercury_data___base_type_info_string_0[];
Word * mercury_data_mercury_builtin__common_7[] = {
	(Word *) (Integer) mercury_data___base_type_info_string_0
};

Word * mercury_data_mercury_builtin__common_8[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_7),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_3),
	(Word *) string_const("term__context", 13)
};

Word * mercury_data_mercury_builtin__common_9[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_const_0
};

Word * mercury_data_mercury_builtin__common_10[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term_0
};

Word * mercury_data_mercury_builtin__common_11[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_term__context_0
};

Word * mercury_data_mercury_builtin__common_12[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_9),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_10),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_11),
	(Word *) string_const("term__functor", 13)
};

Word * mercury_data_mercury_builtin__common_13[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_3),
	(Word *) string_const("term__variable", 14)
};

Word * mercury_data_mercury_builtin__common_14[] = {
	(Word *) ((Integer) 0),
	(Word *) ((Integer) 1),
	(Word *) string_const("[]", 2)
};

Word * mercury_data_mercury_builtin__common_15[] = {
	(Word *) (Integer) mercury_data_mercury_builtin__base_type_info_list_1,
	(Word *) ((Integer) 1)
};

Word * mercury_data_mercury_builtin__common_16[] = {
	(Word *) ((Integer) 2),
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_15),
	(Word *) string_const(".", 1)
};

Word * mercury_data_mercury_builtin__common_17[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_7),
	(Word *) string_const("term__atom", 10)
};

Word * mercury_data_mercury_builtin__common_18[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_3),
	(Word *) string_const("term__integer", 13)
};

Word * mercury_data_mercury_builtin__common_19[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_7),
	(Word *) string_const("term__string", 12)
};

extern Word * mercury_data___base_type_info_float_0[];
Word * mercury_data_mercury_builtin__common_20[] = {
	(Word *) (Integer) mercury_data___base_type_info_float_0
};

Word * mercury_data_mercury_builtin__common_21[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_20),
	(Word *) string_const("term__float", 11)
};

Word * mercury_data_mercury_builtin__common_22[] = {
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 3),
	(Word *) string_const("=", 1),
	(Word *) string_const("<", 1),
	(Word *) string_const(">", 1)
};

Word * mercury_data_mercury_builtin__common_23[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_3),
	(Word *) string_const("base_type_info", 14)
};

BEGIN_MODULE(mercury__mercury_builtin_module0)
	init_entry(mercury____Index___mercury_builtin_term__context_0__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___mercury_builtin_term__context_0__ua10000'/2 in mode 0 */
Define_static(mercury____Index___mercury_builtin_term__context_0__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module1)
	init_entry(mercury____Index___mercury_builtin_list_1__ua10000_2_0);
	init_label(mercury____Index___mercury_builtin_list_1__ua10000_2_0_i3);
BEGIN_CODE

/* code for predicate '__Index___mercury_builtin_list_1__ua10000'/2 in mode 0 */
Define_static(mercury____Index___mercury_builtin_list_1__ua10000_2_0);
	if (((Integer) r1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Index___mercury_builtin_list_1__ua10000_2_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___mercury_builtin_list_1__ua10000_2_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module2)
	init_entry(mercury____Compare___mercury_builtin_base_type_info_1__ua10000_3_0);
BEGIN_CODE

/* code for predicate '__Compare___mercury_builtin_base_type_info_1__ua10000'/3 in mode 0 */
Define_static(mercury____Compare___mercury_builtin_base_type_info_1__ua10000_3_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		tailcall(STATIC(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___mercury_builtin_base_type_info_1__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module3)
	init_entry(mercury____Index___mercury_builtin_base_type_info_1__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___mercury_builtin_base_type_info_1__ua10000'/2 in mode 0 */
Define_static(mercury____Index___mercury_builtin_base_type_info_1__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module4)
	init_entry(mercury____Unify___mercury_builtin_base_type_info_1__ua0_2_0);
	init_label(mercury____Unify___mercury_builtin_base_type_info_1__ua0_2_0_i1);
BEGIN_CODE

/* code for predicate '__Unify___mercury_builtin_base_type_info_1__ua0'/2 in mode 0 */
Define_static(mercury____Unify___mercury_builtin_base_type_info_1__ua0_2_0);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mercury_builtin_base_type_info_1__ua0_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin_base_type_info_1__ua0_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module5)
	init_entry(mercury____Compare___mercury_builtin_type_info_1__ua10000_3_0);
BEGIN_CODE

/* code for predicate '__Compare___mercury_builtin_type_info_1__ua10000'/3 in mode 0 */
Define_static(mercury____Compare___mercury_builtin_type_info_1__ua10000_3_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	tailcall(STATIC(mercury____Compare___mercury_builtin_base_type_info_1__ua10000_3_0),
		STATIC(mercury____Compare___mercury_builtin_type_info_1__ua10000_3_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module6)
	init_entry(mercury____Index___mercury_builtin_type_info_1__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___mercury_builtin_type_info_1__ua10000'/2 in mode 0 */
Define_static(mercury____Index___mercury_builtin_type_info_1__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module7)
	init_entry(mercury____Unify___mercury_builtin_type_info_1__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Unify___mercury_builtin_type_info_1__ua0'/2 in mode 0 */
Define_static(mercury____Unify___mercury_builtin_type_info_1__ua0_2_0);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	tailcall(STATIC(mercury____Unify___mercury_builtin_base_type_info_1__ua0_2_0),
		STATIC(mercury____Unify___mercury_builtin_type_info_1__ua0_2_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module8)
	init_entry(mercury__builtin_type_to_term_pred__ua10000_2_0);
	init_label(mercury__builtin_type_to_term_pred__ua10000_2_0_i4);
	init_label(mercury__builtin_type_to_term_pred__ua10000_2_0_i3);
	init_label(mercury__builtin_type_to_term_pred__ua10000_2_0_i7);
BEGIN_CODE

/* code for predicate 'builtin_type_to_term_pred__ua10000'/2 in mode 0 */
Define_static(mercury__builtin_type_to_term_pred__ua10000_2_0);
	incr_sp_push_msg(1, "builtin_type_to_term_pred__ua10000");
	detstackvar(1) = (Integer) succip;
	call_localret(ENTRY(mercury__std_util__semidet_succeed_0_0),
		mercury__builtin_type_to_term_pred__ua10000_2_0_i4,
		STATIC(mercury__builtin_type_to_term_pred__ua10000_2_0));
Define_label(mercury__builtin_type_to_term_pred__ua10000_2_0_i4);
	update_prof_current_proc(LABEL(mercury__builtin_type_to_term_pred__ua10000_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__builtin_type_to_term_pred__ua10000_2_0_i3);
	r1 = string_const("attempted comparison of higher-order predicate terms", 52);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__builtin_type_to_term_pred__ua10000_2_0));
	}
Define_label(mercury__builtin_type_to_term_pred__ua10000_2_0_i3);
	{
		call_localret(STATIC(mercury__term__context_init_1_0),
		mercury__builtin_type_to_term_pred__ua10000_2_0_i7,
		STATIC(mercury__builtin_type_to_term_pred__ua10000_2_0));
	}
Define_label(mercury__builtin_type_to_term_pred__ua10000_2_0_i7);
	update_prof_current_proc(LABEL(mercury__builtin_type_to_term_pred__ua10000_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_0);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module9)
	init_entry(mercury__builtin_term_to_type_pred__ua0_2_0);
	init_label(mercury__builtin_term_to_type_pred__ua0_2_0_i2);
	init_label(mercury__builtin_term_to_type_pred__ua0_2_0_i6);
	init_label(mercury__builtin_term_to_type_pred__ua0_2_0_i8);
	init_label(mercury__builtin_term_to_type_pred__ua0_2_0_i5);
	init_label(mercury__builtin_term_to_type_pred__ua0_2_0_i1);
BEGIN_CODE

/* code for predicate 'builtin_term_to_type_pred__ua0'/2 in mode 0 */
Define_static(mercury__builtin_term_to_type_pred__ua0_2_0);
	incr_sp_push_msg(1, "builtin_term_to_type_pred__ua0");
	detstackvar(1) = (Integer) succip;
	call_localret(ENTRY(mercury__std_util__semidet_succeed_0_0),
		mercury__builtin_term_to_type_pred__ua0_2_0_i2,
		STATIC(mercury__builtin_term_to_type_pred__ua0_2_0));
Define_label(mercury__builtin_term_to_type_pred__ua0_2_0_i2);
	update_prof_current_proc(LABEL(mercury__builtin_term_to_type_pred__ua0_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__builtin_term_to_type_pred__ua0_2_0_i1);
	call_localret(ENTRY(mercury__std_util__semidet_succeed_0_0),
		mercury__builtin_term_to_type_pred__ua0_2_0_i6,
		STATIC(mercury__builtin_term_to_type_pred__ua0_2_0));
Define_label(mercury__builtin_term_to_type_pred__ua0_2_0_i6);
	update_prof_current_proc(LABEL(mercury__builtin_term_to_type_pred__ua0_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__builtin_term_to_type_pred__ua0_2_0_i5);
	r1 = string_const("attempted conversion of a term to a higher-order predicate", 58);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__builtin_term_to_type_pred__ua0_2_0_i8,
		STATIC(mercury__builtin_term_to_type_pred__ua0_2_0));
	}
Define_label(mercury__builtin_term_to_type_pred__ua0_2_0_i8);
	update_prof_current_proc(LABEL(mercury__builtin_term_to_type_pred__ua0_2_0));
	r2 = (Integer) r1;
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__builtin_term_to_type_pred__ua0_2_0_i5);
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_1);
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__builtin_term_to_type_pred__ua0_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module10)
	init_entry(mercury__builtin_compare_pred__ua10000_3_0);
	init_label(mercury__builtin_compare_pred__ua10000_3_0_i4);
	init_label(mercury__builtin_compare_pred__ua10000_3_0_i1000);
BEGIN_CODE

/* code for predicate 'builtin_compare_pred__ua10000'/3 in mode 0 */
Define_static(mercury__builtin_compare_pred__ua10000_3_0);
	incr_sp_push_msg(1, "builtin_compare_pred__ua10000");
	detstackvar(1) = (Integer) succip;
	call_localret(ENTRY(mercury__std_util__semidet_succeed_0_0),
		mercury__builtin_compare_pred__ua10000_3_0_i4,
		STATIC(mercury__builtin_compare_pred__ua10000_3_0));
Define_label(mercury__builtin_compare_pred__ua10000_3_0_i4);
	update_prof_current_proc(LABEL(mercury__builtin_compare_pred__ua10000_3_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__builtin_compare_pred__ua10000_3_0_i1000);
	r1 = string_const("attempted comparison of higher-order predicate terms", 52);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__builtin_compare_pred__ua10000_3_0));
	}
Define_label(mercury__builtin_compare_pred__ua10000_3_0_i1000);
	r1 = ((Integer) 1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module11)
	init_entry(mercury__builtin_index_pred__ua10000_2_0);
BEGIN_CODE

/* code for predicate 'builtin_index_pred__ua10000'/2 in mode 0 */
Define_static(mercury__builtin_index_pred__ua10000_2_0);
	r1 = ((Integer) -1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module12)
	init_entry(mercury__builtin_unify_pred__ua0_2_0);
	init_label(mercury__builtin_unify_pred__ua0_2_0_i4);
	init_label(mercury__builtin_unify_pred__ua0_2_0_i3);
	init_label(mercury__builtin_unify_pred__ua0_2_0_i9);
BEGIN_CODE

/* code for predicate 'builtin_unify_pred__ua0'/2 in mode 0 */
Define_static(mercury__builtin_unify_pred__ua0_2_0);
	incr_sp_push_msg(1, "builtin_unify_pred__ua0");
	detstackvar(1) = (Integer) succip;
	call_localret(ENTRY(mercury__std_util__semidet_succeed_0_0),
		mercury__builtin_unify_pred__ua0_2_0_i4,
		STATIC(mercury__builtin_unify_pred__ua0_2_0));
Define_label(mercury__builtin_unify_pred__ua0_2_0_i4);
	update_prof_current_proc(LABEL(mercury__builtin_unify_pred__ua0_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__builtin_unify_pred__ua0_2_0_i3);
	r1 = string_const("attempted unification of higher-order predicate terms", 53);
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__builtin_unify_pred__ua0_2_0_i9,
		STATIC(mercury__builtin_unify_pred__ua0_2_0));
	}
Define_label(mercury__builtin_unify_pred__ua0_2_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__std_util__semidet_fail_0_0);
	tailcall(ENTRY(mercury__std_util__semidet_fail_0_0),
		STATIC(mercury__builtin_unify_pred__ua0_2_0));
	}
Define_label(mercury__builtin_unify_pred__ua0_2_0_i9);
	update_prof_current_proc(LABEL(mercury__builtin_unify_pred__ua0_2_0));
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module13)
	init_entry(mercury__builtin_index_float__ua10000_2_0);
BEGIN_CODE

/* code for predicate 'builtin_index_float__ua10000'/2 in mode 0 */
Define_static(mercury__builtin_index_float__ua10000_2_0);
	r1 = ((Integer) -1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module14)
	init_entry(mercury__builtin_index_string__ua10000_2_0);
BEGIN_CODE

/* code for predicate 'builtin_index_string__ua10000'/2 in mode 0 */
Define_static(mercury__builtin_index_string__ua10000_2_0);
	r1 = ((Integer) -1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module15)
	init_entry(mercury__f_33_95_95_117_97_49_48_48_48_49_2_0);
BEGIN_CODE

/* code for predicate '!__ua10001'/2 in mode 0 */
Define_static(mercury__f_33_95_95_117_97_49_48_48_48_49_2_0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module16)
	init_entry(mercury__f_33_95_95_117_97_49_48_48_48_48_2_0);
BEGIN_CODE

/* code for predicate '!__ua10000'/2 in mode 0 */
Define_static(mercury__f_33_95_95_117_97_49_48_48_48_48_2_0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module17)
	init_entry(mercury__f_cut_0_0);
BEGIN_CODE

/* code for predicate '!'/0 in mode 0 */
Define_entry(mercury__f_cut_0_0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module18)
	init_entry(mercury__f_cut_2_0);
BEGIN_CODE

/* code for predicate '!'/2 in mode 0 */
Define_entry(mercury__f_cut_2_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__f_33_95_95_117_97_49_48_48_48_48_2_0),
		ENTRY(mercury__f_cut_2_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module19)
	init_entry(mercury__f_cut_2_1);
BEGIN_CODE

/* code for predicate '!'/2 in mode 1 */
Define_entry(mercury__f_cut_2_1);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury__f_33_95_95_117_97_49_48_48_48_49_2_0),
		ENTRY(mercury__f_cut_2_1));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module20)
	init_entry(mercury__det_term_to_type_2_0);
	init_label(mercury__det_term_to_type_2_0_i4);
	init_label(mercury__det_term_to_type_2_0_i1000);
BEGIN_CODE

/* code for predicate 'det_term_to_type'/2 in mode 0 */
Define_entry(mercury__det_term_to_type_2_0);
	incr_sp_push_msg(1, "det_term_to_type");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__term_to_type_2_0);
	call_localret(ENTRY(mercury__term_to_type_2_0),
		mercury__det_term_to_type_2_0_i4,
		ENTRY(mercury__det_term_to_type_2_0));
	}
Define_label(mercury__det_term_to_type_2_0_i4);
	update_prof_current_proc(LABEL(mercury__det_term_to_type_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__det_term_to_type_2_0_i1000);
	r1 = (Integer) r2;
	proceed();
Define_label(mercury__det_term_to_type_2_0_i1000);
	r1 = string_const("det_term_to_type failed as term doesn't represent a valid ground value of the appropriate type", 94);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__det_term_to_type_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module21)
	init_entry(mercury__builtin_unify_int_2_0);
	init_label(mercury__builtin_unify_int_2_0_i1);
BEGIN_CODE

/* code for predicate 'builtin_unify_int'/2 in mode 0 */
Define_entry(mercury__builtin_unify_int_2_0);
	if (((Integer) r2 != (Integer) r1))
		GOTO_LABEL(mercury__builtin_unify_int_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__builtin_unify_int_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module22)
	init_entry(mercury__builtin_index_int_2_0);
BEGIN_CODE

/* code for predicate 'builtin_index_int'/2 in mode 0 */
Define_entry(mercury__builtin_index_int_2_0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module23)
	init_entry(mercury__builtin_compare_int_3_0);
	init_label(mercury__builtin_compare_int_3_0_i2);
	init_label(mercury__builtin_compare_int_3_0_i4);
BEGIN_CODE

/* code for predicate 'builtin_compare_int'/3 in mode 0 */
Define_entry(mercury__builtin_compare_int_3_0);
	if (((Integer) r1 >= (Integer) r2))
		GOTO_LABEL(mercury__builtin_compare_int_3_0_i2);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__builtin_compare_int_3_0_i2);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury__builtin_compare_int_3_0_i4);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__builtin_compare_int_3_0_i4);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module24)
	init_entry(mercury__builtin_term_to_type_int_2_0);
	init_label(mercury__builtin_term_to_type_int_2_0_i1);
BEGIN_CODE

/* code for predicate 'builtin_term_to_type_int'/2 in mode 0 */
Define_entry(mercury__builtin_term_to_type_int_2_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__builtin_term_to_type_int_2_0_i1);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury__builtin_term_to_type_int_2_0_i1);
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__builtin_term_to_type_int_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module25)
	init_entry(mercury__builtin_type_to_term_int_2_0);
	init_label(mercury__builtin_type_to_term_int_2_0_i2);
BEGIN_CODE

/* code for predicate 'builtin_type_to_term_int'/2 in mode 0 */
Define_entry(mercury__builtin_type_to_term_int_2_0);
	tag_incr_hp(r2, mktag(1), ((Integer) 1));
	incr_sp_push_msg(2, "builtin_type_to_term_int");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	{
		call_localret(STATIC(mercury__term__context_init_1_0),
		mercury__builtin_type_to_term_int_2_0_i2,
		ENTRY(mercury__builtin_type_to_term_int_2_0));
	}
Define_label(mercury__builtin_type_to_term_int_2_0_i2);
	update_prof_current_proc(LABEL(mercury__builtin_type_to_term_int_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module26)
	init_entry(mercury__builtin_unify_character_2_0);
	init_label(mercury__builtin_unify_character_2_0_i1);
BEGIN_CODE

/* code for predicate 'builtin_unify_character'/2 in mode 0 */
Define_entry(mercury__builtin_unify_character_2_0);
	if (((Integer) r2 != (Integer) r1))
		GOTO_LABEL(mercury__builtin_unify_character_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__builtin_unify_character_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module27)
	init_entry(mercury__builtin_index_character_2_0);
BEGIN_CODE

/* code for predicate 'builtin_index_character'/2 in mode 0 */
Define_entry(mercury__builtin_index_character_2_0);
	{
	Declare_entry(mercury__char__to_int_2_0);
	tailcall(ENTRY(mercury__char__to_int_2_0),
		ENTRY(mercury__builtin_index_character_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module28)
	init_entry(mercury__builtin_compare_character_3_0);
	init_label(mercury__builtin_compare_character_3_0_i2);
	init_label(mercury__builtin_compare_character_3_0_i3);
	init_label(mercury__builtin_compare_character_3_0_i4);
	init_label(mercury__builtin_compare_character_3_0_i6);
BEGIN_CODE

/* code for predicate 'builtin_compare_character'/3 in mode 0 */
Define_entry(mercury__builtin_compare_character_3_0);
	incr_sp_push_msg(2, "builtin_compare_character");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	{
	Declare_entry(mercury__char__to_int_2_0);
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__builtin_compare_character_3_0_i2,
		ENTRY(mercury__builtin_compare_character_3_0));
	}
Define_label(mercury__builtin_compare_character_3_0_i2);
	update_prof_current_proc(LABEL(mercury__builtin_compare_character_3_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__char__to_int_2_0);
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__builtin_compare_character_3_0_i3,
		ENTRY(mercury__builtin_compare_character_3_0));
	}
Define_label(mercury__builtin_compare_character_3_0_i3);
	update_prof_current_proc(LABEL(mercury__builtin_compare_character_3_0));
	if (((Integer) detstackvar(1) >= (Integer) r1))
		GOTO_LABEL(mercury__builtin_compare_character_3_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__builtin_compare_character_3_0_i4);
	if (((Integer) detstackvar(1) != (Integer) r1))
		GOTO_LABEL(mercury__builtin_compare_character_3_0_i6);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__builtin_compare_character_3_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module29)
	init_entry(mercury__builtin_term_to_type_character_2_0);
	init_label(mercury__builtin_term_to_type_character_2_0_i5);
	init_label(mercury__builtin_term_to_type_character_2_0_i1005);
	init_label(mercury__builtin_term_to_type_character_2_0_i1007);
BEGIN_CODE

/* code for predicate 'builtin_term_to_type_character'/2 in mode 0 */
Define_entry(mercury__builtin_term_to_type_character_2_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__builtin_term_to_type_character_2_0_i1005);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__builtin_term_to_type_character_2_0_i1005);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__builtin_term_to_type_character_2_0_i1005);
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	r2 = string_const("", 0);
	incr_sp_push_msg(1, "builtin_term_to_type_character");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__string__first_char_3_1);
	call_localret(ENTRY(mercury__string__first_char_3_1),
		mercury__builtin_term_to_type_character_2_0_i5,
		ENTRY(mercury__builtin_term_to_type_character_2_0));
	}
Define_label(mercury__builtin_term_to_type_character_2_0_i5);
	update_prof_current_proc(LABEL(mercury__builtin_term_to_type_character_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__builtin_term_to_type_character_2_0_i1007);
	r1 = TRUE;
	proceed();
Define_label(mercury__builtin_term_to_type_character_2_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury__builtin_term_to_type_character_2_0_i1007);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module30)
	init_entry(mercury__builtin_type_to_term_character_2_0);
	init_label(mercury__builtin_type_to_term_character_2_0_i2);
	init_label(mercury__builtin_type_to_term_character_2_0_i3);
BEGIN_CODE

/* code for predicate 'builtin_type_to_term_character'/2 in mode 0 */
Define_entry(mercury__builtin_type_to_term_character_2_0);
	incr_sp_push_msg(2, "builtin_type_to_term_character");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	{
		call_localret(STATIC(mercury__term__context_init_1_0),
		mercury__builtin_type_to_term_character_2_0_i2,
		ENTRY(mercury__builtin_type_to_term_character_2_0));
	}
Define_label(mercury__builtin_type_to_term_character_2_0_i2);
	update_prof_current_proc(LABEL(mercury__builtin_type_to_term_character_2_0));
	r2 = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) r2;
	{
	Declare_entry(mercury__string__char_to_string_2_0);
	call_localret(ENTRY(mercury__string__char_to_string_2_0),
		mercury__builtin_type_to_term_character_2_0_i3,
		ENTRY(mercury__builtin_type_to_term_character_2_0));
	}
Define_label(mercury__builtin_type_to_term_character_2_0_i3);
	update_prof_current_proc(LABEL(mercury__builtin_type_to_term_character_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	tag_incr_hp(r3, mktag(0), ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) r3;
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module31)
	init_entry(mercury__builtin_unify_string_2_0);
	init_label(mercury__builtin_unify_string_2_0_i1);
BEGIN_CODE

/* code for predicate 'builtin_unify_string'/2 in mode 0 */
Define_entry(mercury__builtin_unify_string_2_0);
	if ((strcmp((char *)(Integer) r2, (char *)(Integer) r1) !=0))
		GOTO_LABEL(mercury__builtin_unify_string_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__builtin_unify_string_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module32)
	init_entry(mercury__builtin_index_string_2_0);
BEGIN_CODE

/* code for predicate 'builtin_index_string'/2 in mode 0 */
Define_entry(mercury__builtin_index_string_2_0);
	tailcall(STATIC(mercury__builtin_index_string__ua10000_2_0),
		ENTRY(mercury__builtin_index_string_2_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module33)
	init_entry(mercury__builtin_compare_string_3_0);
	init_label(mercury__builtin_compare_string_3_0_i2);
	init_label(mercury__builtin_compare_string_3_0_i3);
	init_label(mercury__builtin_compare_string_3_0_i1000);
BEGIN_CODE

/* code for predicate 'builtin_compare_string'/3 in mode 0 */
Define_entry(mercury__builtin_compare_string_3_0);
	incr_sp_push_msg(1, "builtin_compare_string");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__builtin_strcmp_3_0),
		mercury__builtin_compare_string_3_0_i2,
		ENTRY(mercury__builtin_compare_string_3_0));
Define_label(mercury__builtin_compare_string_3_0_i2);
	update_prof_current_proc(LABEL(mercury__builtin_compare_string_3_0));
	if (((Integer) r1 >= ((Integer) 0)))
		GOTO_LABEL(mercury__builtin_compare_string_3_0_i3);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__builtin_compare_string_3_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__builtin_compare_string_3_0_i1000);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury__builtin_compare_string_3_0_i1000);
	r1 = ((Integer) 2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module34)
	init_entry(mercury__builtin_term_to_type_string_2_0);
	init_label(mercury__builtin_term_to_type_string_2_0_i1);
BEGIN_CODE

/* code for predicate 'builtin_term_to_type_string'/2 in mode 0 */
Define_entry(mercury__builtin_term_to_type_string_2_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__builtin_term_to_type_string_2_0_i1);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury__builtin_term_to_type_string_2_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury__builtin_term_to_type_string_2_0_i1);
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__builtin_term_to_type_string_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module35)
	init_entry(mercury__builtin_type_to_term_string_2_0);
	init_label(mercury__builtin_type_to_term_string_2_0_i2);
BEGIN_CODE

/* code for predicate 'builtin_type_to_term_string'/2 in mode 0 */
Define_entry(mercury__builtin_type_to_term_string_2_0);
	tag_incr_hp(r2, mktag(2), ((Integer) 1));
	incr_sp_push_msg(2, "builtin_type_to_term_string");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	field(mktag(2), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	{
		call_localret(STATIC(mercury__term__context_init_1_0),
		mercury__builtin_type_to_term_string_2_0_i2,
		ENTRY(mercury__builtin_type_to_term_string_2_0));
	}
Define_label(mercury__builtin_type_to_term_string_2_0_i2);
	update_prof_current_proc(LABEL(mercury__builtin_type_to_term_string_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module36)
	init_entry(mercury__builtin_unify_float_2_0);
	init_label(mercury__builtin_unify_float_2_0_i1);
BEGIN_CODE

/* code for predicate 'builtin_unify_float'/2 in mode 0 */
Define_entry(mercury__builtin_unify_float_2_0);
	if ((word_to_float((Integer) r2) != word_to_float((Integer) r1)))
		GOTO_LABEL(mercury__builtin_unify_float_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__builtin_unify_float_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module37)
	init_entry(mercury__builtin_index_float_2_0);
BEGIN_CODE

/* code for predicate 'builtin_index_float'/2 in mode 0 */
Define_entry(mercury__builtin_index_float_2_0);
	tailcall(STATIC(mercury__builtin_index_float__ua10000_2_0),
		ENTRY(mercury__builtin_index_float_2_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module38)
	init_entry(mercury__builtin_compare_float_3_0);
	init_label(mercury__builtin_compare_float_3_0_i2);
	init_label(mercury__builtin_compare_float_3_0_i4);
BEGIN_CODE

/* code for predicate 'builtin_compare_float'/3 in mode 0 */
Define_entry(mercury__builtin_compare_float_3_0);
	if ((word_to_float((Integer) r1) >= word_to_float((Integer) r2)))
		GOTO_LABEL(mercury__builtin_compare_float_3_0_i2);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury__builtin_compare_float_3_0_i2);
	if ((word_to_float((Integer) r1) <= word_to_float((Integer) r2)))
		GOTO_LABEL(mercury__builtin_compare_float_3_0_i4);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury__builtin_compare_float_3_0_i4);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module39)
	init_entry(mercury__builtin_term_to_type_float_2_0);
	init_label(mercury__builtin_term_to_type_float_2_0_i1);
BEGIN_CODE

/* code for predicate 'builtin_term_to_type_float'/2 in mode 0 */
Define_entry(mercury__builtin_term_to_type_float_2_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury__builtin_term_to_type_float_2_0_i1);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury__builtin_term_to_type_float_2_0_i1);
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__builtin_term_to_type_float_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module40)
	init_entry(mercury__builtin_type_to_term_float_2_0);
	init_label(mercury__builtin_type_to_term_float_2_0_i2);
BEGIN_CODE

/* code for predicate 'builtin_type_to_term_float'/2 in mode 0 */
Define_entry(mercury__builtin_type_to_term_float_2_0);
	tag_incr_hp(r2, mktag(3), ((Integer) 1));
	incr_sp_push_msg(2, "builtin_type_to_term_float");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	field(mktag(3), (Integer) r2, ((Integer) 0)) = (Integer) r1;
	{
		call_localret(STATIC(mercury__term__context_init_1_0),
		mercury__builtin_type_to_term_float_2_0_i2,
		ENTRY(mercury__builtin_type_to_term_float_2_0));
	}
Define_label(mercury__builtin_type_to_term_float_2_0_i2);
	update_prof_current_proc(LABEL(mercury__builtin_type_to_term_float_2_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module41)
	init_entry(mercury__builtin_unify_pred_2_0);
BEGIN_CODE

/* code for predicate 'builtin_unify_pred'/2 in mode 0 */
Define_entry(mercury__builtin_unify_pred_2_0);
	tailcall(STATIC(mercury__builtin_unify_pred__ua0_2_0),
		ENTRY(mercury__builtin_unify_pred_2_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module42)
	init_entry(mercury__builtin_index_pred_2_0);
BEGIN_CODE

/* code for predicate 'builtin_index_pred'/2 in mode 0 */
Define_entry(mercury__builtin_index_pred_2_0);
	tailcall(STATIC(mercury__builtin_index_pred__ua10000_2_0),
		ENTRY(mercury__builtin_index_pred_2_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module43)
	init_entry(mercury__builtin_compare_pred_3_0);
BEGIN_CODE

/* code for predicate 'builtin_compare_pred'/3 in mode 0 */
Define_entry(mercury__builtin_compare_pred_3_0);
	tailcall(STATIC(mercury__builtin_compare_pred__ua10000_3_0),
		ENTRY(mercury__builtin_compare_pred_3_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module44)
	init_entry(mercury__builtin_term_to_type_pred_2_0);
	init_label(mercury__builtin_term_to_type_pred_2_0_i2);
	init_label(mercury__builtin_term_to_type_pred_2_0_i1000);
BEGIN_CODE

/* code for predicate 'builtin_term_to_type_pred'/2 in mode 0 */
Define_entry(mercury__builtin_term_to_type_pred_2_0);
	incr_sp_push_msg(2, "builtin_term_to_type_pred");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	call_localret(STATIC(mercury__builtin_term_to_type_pred__ua0_2_0),
		mercury__builtin_term_to_type_pred_2_0_i2,
		ENTRY(mercury__builtin_term_to_type_pred_2_0));
Define_label(mercury__builtin_term_to_type_pred_2_0_i2);
	update_prof_current_proc(LABEL(mercury__builtin_term_to_type_pred_2_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__builtin_term_to_type_pred_2_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__builtin_term_to_type_pred_2_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module45)
	init_entry(mercury__builtin_type_to_term_pred_2_0);
BEGIN_CODE

/* code for predicate 'builtin_type_to_term_pred'/2 in mode 0 */
Define_entry(mercury__builtin_type_to_term_pred_2_0);
	tailcall(STATIC(mercury__builtin_type_to_term_pred__ua10000_2_0),
		ENTRY(mercury__builtin_type_to_term_pred_2_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module46)
	init_entry(mercury__unused_0_0);
	init_label(mercury__unused_0_0_i4);
	init_label(mercury__unused_0_0_i1000);
BEGIN_CODE

/* code for predicate 'unused'/0 in mode 0 */
Define_entry(mercury__unused_0_0);
	incr_sp_push_msg(1, "unused");
	detstackvar(1) = (Integer) succip;
	call_localret(ENTRY(mercury__std_util__semidet_succeed_0_0),
		mercury__unused_0_0_i4,
		ENTRY(mercury__unused_0_0));
Define_label(mercury__unused_0_0_i4);
	update_prof_current_proc(LABEL(mercury__unused_0_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__unused_0_0_i1000);
	r1 = string_const("attempted use of dead predicate", 31);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__unused_0_0));
	}
Define_label(mercury__unused_0_0_i1000);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module47)
	init_entry(mercury__compare_error_0_0);
	init_label(mercury__compare_error_0_0_i2);
BEGIN_CODE

/* code for predicate 'compare_error'/0 in mode 0 */
Define_entry(mercury__compare_error_0_0);
	r1 = string_const("internal error in compare/3", 27);
	incr_sp_push_msg(1, "compare_error");
	{
	Declare_entry(mercury__require__error_1_0);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__compare_error_0_0_i2,
		ENTRY(mercury__compare_error_0_0));
	}
Define_label(mercury__compare_error_0_0_i2);
	update_prof_current_proc(LABEL(mercury__compare_error_0_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module48)
	init_entry(mercury__term__init_var_supply_1_1);
	init_label(mercury__term__init_var_supply_1_1_i1);
BEGIN_CODE

/* code for predicate 'term__init_var_supply'/1 in mode 1 */
Define_entry(mercury__term__init_var_supply_1_1);
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury__term__init_var_supply_1_1_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__term__init_var_supply_1_1_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module49)
	init_entry(mercury__term__init_var_supply_1_0);
BEGIN_CODE

/* code for predicate 'term__init_var_supply'/1 in mode 0 */
Define_entry(mercury__term__init_var_supply_1_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module50)
	init_entry(mercury__term__create_var_3_0);
BEGIN_CODE

/* code for predicate 'term__create_var'/3 in mode 0 */
Define_entry(mercury__term__create_var_3_0);
	r1 = ((Integer) r1 + ((Integer) 1));
	r2 = (Integer) r1;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module51)
	init_entry(mercury__term__var_to_int_2_0);
BEGIN_CODE

/* code for predicate 'term__var_to_int'/2 in mode 0 */
Define_entry(mercury__term__var_to_int_2_0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module52)
	init_entry(mercury__term__context_init_1_0);
BEGIN_CODE

/* code for predicate 'term__context_init'/1 in mode 0 */
Define_entry(mercury__term__context_init_1_0);
	r1 = (Integer) mkword(mktag(0), (Integer) mercury_data_mercury_builtin__common_2);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module53)
	init_entry(mercury__builtin_strcmp_3_0);
BEGIN_CODE

/* code for predicate 'builtin_strcmp'/3 in mode 0 */
Define_static(mercury__builtin_strcmp_3_0);
	{
		Integer	Res;
		String	S1;
		String	S2;
		S1 = (String) (Integer) r1;
		S2 = (String) (Integer) r2;
		Res = strcmp(S1, S2);
		r3 = Res;

	}
	r1 = (Integer) r3;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module54)
	init_entry(mercury____Unify___mercury_builtin__c_pointer_0_0);
	init_label(mercury____Unify___mercury_builtin__c_pointer_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mercury_builtin__c_pointer_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___mercury_builtin__c_pointer_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__c_pointer_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module55)
	init_entry(mercury____Index___mercury_builtin__c_pointer_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mercury_builtin__c_pointer_0_0);
	{
		tailcall(STATIC(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___mercury_builtin__c_pointer_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module56)
	init_entry(mercury____Compare___mercury_builtin__c_pointer_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mercury_builtin__c_pointer_0_0);
	{
		tailcall(STATIC(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mercury_builtin__c_pointer_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module57)
	init_entry(mercury____Unify___mercury_builtin__comparison_result_0_0);
	init_label(mercury____Unify___mercury_builtin__comparison_result_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mercury_builtin__comparison_result_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___mercury_builtin__comparison_result_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__comparison_result_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module58)
	init_entry(mercury____Index___mercury_builtin__comparison_result_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mercury_builtin__comparison_result_0_0);
	{
		tailcall(STATIC(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___mercury_builtin__comparison_result_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module59)
	init_entry(mercury____Compare___mercury_builtin__comparison_result_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mercury_builtin__comparison_result_0_0);
	{
		tailcall(STATIC(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mercury_builtin__comparison_result_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module60)
	init_entry(mercury____Unify___mercury_builtin__type_info_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mercury_builtin__type_info_1_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury____Unify___mercury_builtin_type_info_1__ua0_2_0),
		ENTRY(mercury____Unify___mercury_builtin__type_info_1_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module61)
	init_entry(mercury____Index___mercury_builtin__type_info_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mercury_builtin__type_info_1_0);
	tailcall(STATIC(mercury____Index___mercury_builtin_type_info_1__ua10000_2_0),
		ENTRY(mercury____Index___mercury_builtin__type_info_1_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module62)
	init_entry(mercury____Compare___mercury_builtin__type_info_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mercury_builtin__type_info_1_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury____Compare___mercury_builtin_type_info_1__ua10000_3_0),
		ENTRY(mercury____Compare___mercury_builtin__type_info_1_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module63)
	init_entry(mercury____Unify___mercury_builtin__base_type_info_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mercury_builtin__base_type_info_1_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury____Unify___mercury_builtin_base_type_info_1__ua0_2_0),
		ENTRY(mercury____Unify___mercury_builtin__base_type_info_1_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module64)
	init_entry(mercury____Index___mercury_builtin__base_type_info_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mercury_builtin__base_type_info_1_0);
	tailcall(STATIC(mercury____Index___mercury_builtin_base_type_info_1__ua10000_2_0),
		ENTRY(mercury____Index___mercury_builtin__base_type_info_1_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module65)
	init_entry(mercury____Compare___mercury_builtin__base_type_info_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mercury_builtin__base_type_info_1_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury____Compare___mercury_builtin_base_type_info_1__ua10000_3_0),
		ENTRY(mercury____Compare___mercury_builtin__base_type_info_1_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module66)
	init_entry(mercury____Unify___mercury_builtin__term_0_0);
	init_label(mercury____Unify___mercury_builtin__term_0_0_i5);
	init_label(mercury____Unify___mercury_builtin__term_0_0_i7);
	init_label(mercury____Unify___mercury_builtin__term_0_0_i1010);
	init_label(mercury____Unify___mercury_builtin__term_0_0_i1007);
	init_label(mercury____Unify___mercury_builtin__term_0_0_i1);
	init_label(mercury____Unify___mercury_builtin__term_0_0_i1009);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mercury_builtin__term_0_0);
	if ((tag((Integer) r1) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__term_0_0_i1010);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__term_0_0_i1007);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury____Unify___mercury_builtin__const_0_0),
		mercury____Unify___mercury_builtin__term_0_0_i5,
		ENTRY(mercury____Unify___mercury_builtin__term_0_0));
	}
Define_label(mercury____Unify___mercury_builtin__term_0_0_i5);
	update_prof_current_proc(LABEL(mercury____Unify___mercury_builtin__term_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mercury_builtin__term_0_0_i1);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury____Unify___mercury_builtin__list_1_0),
		mercury____Unify___mercury_builtin__term_0_0_i7,
		ENTRY(mercury____Unify___mercury_builtin__term_0_0));
	}
Define_label(mercury____Unify___mercury_builtin__term_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Unify___mercury_builtin__term_0_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mercury_builtin__term_0_0_i1);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury____Unify___mercury_builtin__term__context_0_0),
		ENTRY(mercury____Unify___mercury_builtin__term_0_0));
	}
Define_label(mercury____Unify___mercury_builtin__term_0_0_i1010);
	incr_sp_push_msg(5, "__Unify__");
	detstackvar(5) = (Integer) succip;
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__term_0_0_i1);
	r3 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	decr_sp_pop_msg(5);
	if (((Integer) r3 != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__term_0_0_i1009);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__term_0_0_i1007);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__term_0_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___mercury_builtin__term_0_0_i1009);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module67)
	init_entry(mercury____Index___mercury_builtin__term_0_0);
	init_label(mercury____Index___mercury_builtin__term_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mercury_builtin__term_0_0);
	if ((tag((Integer) r1) == mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___mercury_builtin__term_0_0_i3);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___mercury_builtin__term_0_0_i3);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module68)
	init_entry(mercury____Compare___mercury_builtin__term_0_0);
	init_label(mercury____Compare___mercury_builtin__term_0_0_i2);
	init_label(mercury____Compare___mercury_builtin__term_0_0_i3);
	init_label(mercury____Compare___mercury_builtin__term_0_0_i4);
	init_label(mercury____Compare___mercury_builtin__term_0_0_i6);
	init_label(mercury____Compare___mercury_builtin__term_0_0_i15);
	init_label(mercury____Compare___mercury_builtin__term_0_0_i16);
	init_label(mercury____Compare___mercury_builtin__term_0_0_i14);
	init_label(mercury____Compare___mercury_builtin__term_0_0_i21);
	init_label(mercury____Compare___mercury_builtin__term_0_0_i11);
	init_label(mercury____Compare___mercury_builtin__term_0_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mercury_builtin__term_0_0);
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___mercury_builtin__term_0_0),
		mercury____Compare___mercury_builtin__term_0_0_i2,
		ENTRY(mercury____Compare___mercury_builtin__term_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__term_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_builtin__term_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___mercury_builtin__term_0_0),
		mercury____Compare___mercury_builtin__term_0_0_i3,
		ENTRY(mercury____Compare___mercury_builtin__term_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__term_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_builtin__term_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mercury_builtin__term_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___mercury_builtin__term_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mercury_builtin__term_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___mercury_builtin__term_0_0_i6);
	if ((tag((Integer) detstackvar(1)) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__term_0_0_i11);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__term_0_0_i9);
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(1);
	r1 = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	{
		call_localret(STATIC(mercury____Compare___mercury_builtin__const_0_0),
		mercury____Compare___mercury_builtin__term_0_0_i15,
		ENTRY(mercury____Compare___mercury_builtin__term_0_0));
	}
	}
Define_label(mercury____Compare___mercury_builtin__term_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_builtin__term_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mercury_builtin__term_0_0_i14);
Define_label(mercury____Compare___mercury_builtin__term_0_0_i16);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___mercury_builtin__term_0_0_i14);
	r1 = (Integer) mercury_data_mercury_builtin__base_type_info_term_0;
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(3);
	{
		call_localret(STATIC(mercury____Compare___mercury_builtin__list_1_0),
		mercury____Compare___mercury_builtin__term_0_0_i21,
		ENTRY(mercury____Compare___mercury_builtin__term_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__term_0_0_i21);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_builtin__term_0_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mercury_builtin__term_0_0_i16);
	r1 = (Integer) detstackvar(2);
	r2 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury____Compare___mercury_builtin__term__context_0_0),
		ENTRY(mercury____Compare___mercury_builtin__term_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__term_0_0_i11);
	r3 = (Integer) detstackvar(2);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__term_0_0_i9);
	r1 = (Integer) field(mktag(1), (Integer) detstackvar(1), ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mercury_builtin__term_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__term_0_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___mercury_builtin__term_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module69)
	init_entry(mercury____Unify___mercury_builtin__const_0_0);
	init_label(mercury____Unify___mercury_builtin__const_0_0_i4);
	init_label(mercury____Unify___mercury_builtin__const_0_0_i6);
	init_label(mercury____Unify___mercury_builtin__const_0_0_i8);
	init_label(mercury____Unify___mercury_builtin__const_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mercury_builtin__const_0_0);
	r3 = tag((Integer) r1);
	if (((Integer) r3 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__const_0_0_i4);
	if ((tag((Integer) r2) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__const_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___mercury_builtin__const_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__const_0_0_i4);
	if (((Integer) r3 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__const_0_0_i6);
	if ((tag((Integer) r2) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__const_0_0_i1);
	if (((Integer) field(mktag(1), (Integer) r1, ((Integer) 0)) != (Integer) field(mktag(1), (Integer) r2, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__const_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__const_0_0_i6);
	if (((Integer) r3 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__const_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__const_0_0_i1);
	if ((strcmp((char *)(Integer) field(mktag(2), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(2), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___mercury_builtin__const_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__const_0_0_i8);
	if ((tag((Integer) r2) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__const_0_0_i1);
	if ((word_to_float((Integer) field(mktag(3), (Integer) r1, ((Integer) 0))) != word_to_float((Integer) field(mktag(3), (Integer) r2, ((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__const_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__const_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module70)
	init_entry(mercury____Index___mercury_builtin__const_0_0);
	init_label(mercury____Index___mercury_builtin__const_0_0_i4);
	init_label(mercury____Index___mercury_builtin__const_0_0_i5);
	init_label(mercury____Index___mercury_builtin__const_0_0_i6);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mercury_builtin__const_0_0);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Index___mercury_builtin__const_0_0_i4);
	r1 = ((Integer) 0);
	proceed();
Define_label(mercury____Index___mercury_builtin__const_0_0_i4);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Index___mercury_builtin__const_0_0_i5);
	r1 = ((Integer) 1);
	proceed();
Define_label(mercury____Index___mercury_builtin__const_0_0_i5);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Index___mercury_builtin__const_0_0_i6);
	r1 = ((Integer) 2);
	proceed();
Define_label(mercury____Index___mercury_builtin__const_0_0_i6);
	r1 = ((Integer) 3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module71)
	init_entry(mercury____Compare___mercury_builtin__const_0_0);
	init_label(mercury____Compare___mercury_builtin__const_0_0_i2);
	init_label(mercury____Compare___mercury_builtin__const_0_0_i3);
	init_label(mercury____Compare___mercury_builtin__const_0_0_i4);
	init_label(mercury____Compare___mercury_builtin__const_0_0_i6);
	init_label(mercury____Compare___mercury_builtin__const_0_0_i12);
	init_label(mercury____Compare___mercury_builtin__const_0_0_i15);
	init_label(mercury____Compare___mercury_builtin__const_0_0_i18);
	init_label(mercury____Compare___mercury_builtin__const_0_0_i1000);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mercury_builtin__const_0_0);
	incr_sp_push_msg(4, "__Compare__");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r1;
	detstackvar(2) = (Integer) r2;
	{
		call_localret(STATIC(mercury____Index___mercury_builtin__const_0_0),
		mercury____Compare___mercury_builtin__const_0_0_i2,
		ENTRY(mercury____Compare___mercury_builtin__const_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__const_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_builtin__const_0_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	{
		call_localret(STATIC(mercury____Index___mercury_builtin__const_0_0),
		mercury____Compare___mercury_builtin__const_0_0_i3,
		ENTRY(mercury____Compare___mercury_builtin__const_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__const_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_builtin__const_0_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mercury_builtin__const_0_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mercury_builtin__const_0_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mercury_builtin__const_0_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___mercury_builtin__const_0_0_i6);
	r1 = (Integer) detstackvar(1);
	r2 = tag((Integer) r1);
	if (((Integer) r2 != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__const_0_0_i12);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 0))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__const_0_0_i1000);
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	{
		tailcall(STATIC(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___mercury_builtin__const_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__const_0_0_i12);
	if (((Integer) r2 != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__const_0_0_i15);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 1))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__const_0_0_i1000);
	r1 = (Integer) field(mktag(1), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
		tailcall(STATIC(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mercury_builtin__const_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__const_0_0_i15);
	if (((Integer) r2 != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__const_0_0_i18);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 2))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__const_0_0_i1000);
	r1 = (Integer) field(mktag(2), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(2), (Integer) r3, ((Integer) 0));
	{
		tailcall(STATIC(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___mercury_builtin__const_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__const_0_0_i18);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	if ((tag((Integer) r3) != mktag(((Integer) 3))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__const_0_0_i1000);
	r1 = (Integer) field(mktag(3), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(3), (Integer) r3, ((Integer) 0));
	{
		tailcall(STATIC(mercury__builtin_compare_float_3_0),
		ENTRY(mercury____Compare___mercury_builtin__const_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__const_0_0_i1000);
	{
		tailcall(STATIC(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___mercury_builtin__const_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module72)
	init_entry(mercury____Unify___mercury_builtin__var_0_0);
	init_label(mercury____Unify___mercury_builtin__var_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mercury_builtin__var_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___mercury_builtin__var_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__var_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module73)
	init_entry(mercury____Index___mercury_builtin__var_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mercury_builtin__var_0_0);
	{
		tailcall(STATIC(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___mercury_builtin__var_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module74)
	init_entry(mercury____Compare___mercury_builtin__var_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mercury_builtin__var_0_0);
	{
		tailcall(STATIC(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mercury_builtin__var_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module75)
	init_entry(mercury____Unify___mercury_builtin__var_supply_0_0);
	init_label(mercury____Unify___mercury_builtin__var_supply_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mercury_builtin__var_supply_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___mercury_builtin__var_supply_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__var_supply_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module76)
	init_entry(mercury____Index___mercury_builtin__var_supply_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mercury_builtin__var_supply_0_0);
	{
		tailcall(STATIC(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___mercury_builtin__var_supply_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module77)
	init_entry(mercury____Compare___mercury_builtin__var_supply_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mercury_builtin__var_supply_0_0);
	{
		tailcall(STATIC(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mercury_builtin__var_supply_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module78)
	init_entry(mercury____Unify___mercury_builtin__list_1_0);
	init_label(mercury____Unify___mercury_builtin__list_1_0_i1009);
	init_label(mercury____Unify___mercury_builtin__list_1_0_i6);
	init_label(mercury____Unify___mercury_builtin__list_1_0_i1006);
	init_label(mercury____Unify___mercury_builtin__list_1_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mercury_builtin__list_1_0);
	if (((Integer) r2 != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__list_1_0_i1009);
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__list_1_0_i1006);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__list_1_0_i1009);
	incr_sp_push_msg(4, "__Unify__");
	detstackvar(4) = (Integer) succip;
	if (((Integer) r3 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__list_1_0_i1);
	detstackvar(1) = (Integer) field(mktag(1), (Integer) r2, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) r3, ((Integer) 1));
	detstackvar(3) = (Integer) r1;
	r2 = (Integer) field(mktag(1), (Integer) r2, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) r3, ((Integer) 0));
	{
	Declare_entry(mercury__unify_2_0);
	call_localret(ENTRY(mercury__unify_2_0),
		mercury____Unify___mercury_builtin__list_1_0_i6,
		ENTRY(mercury____Unify___mercury_builtin__list_1_0));
	}
Define_label(mercury____Unify___mercury_builtin__list_1_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___mercury_builtin__list_1_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___mercury_builtin__list_1_0_i1);
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	localtailcall(mercury____Unify___mercury_builtin__list_1_0,
		ENTRY(mercury____Unify___mercury_builtin__list_1_0));
Define_label(mercury____Unify___mercury_builtin__list_1_0_i1006);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__list_1_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module79)
	init_entry(mercury____Index___mercury_builtin__list_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mercury_builtin__list_1_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury____Index___mercury_builtin_list_1__ua10000_2_0),
		ENTRY(mercury____Index___mercury_builtin__list_1_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module80)
	init_entry(mercury____Compare___mercury_builtin__list_1_0);
	init_label(mercury____Compare___mercury_builtin__list_1_0_i2);
	init_label(mercury____Compare___mercury_builtin__list_1_0_i3);
	init_label(mercury____Compare___mercury_builtin__list_1_0_i4);
	init_label(mercury____Compare___mercury_builtin__list_1_0_i6);
	init_label(mercury____Compare___mercury_builtin__list_1_0_i11);
	init_label(mercury____Compare___mercury_builtin__list_1_0_i16);
	init_label(mercury____Compare___mercury_builtin__list_1_0_i15);
	init_label(mercury____Compare___mercury_builtin__list_1_0_i9);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mercury_builtin__list_1_0);
	incr_sp_push_msg(5, "__Compare__");
	detstackvar(5) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	detstackvar(2) = (Integer) r3;
	detstackvar(4) = (Integer) r1;
	r1 = (Integer) r2;
	call_localret(STATIC(mercury____Index___mercury_builtin_list_1__ua10000_2_0),
		mercury____Compare___mercury_builtin__list_1_0_i2,
		ENTRY(mercury____Compare___mercury_builtin__list_1_0));
Define_label(mercury____Compare___mercury_builtin__list_1_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_builtin__list_1_0));
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) detstackvar(2);
	call_localret(STATIC(mercury____Index___mercury_builtin_list_1__ua10000_2_0),
		mercury____Compare___mercury_builtin__list_1_0_i3,
		ENTRY(mercury____Compare___mercury_builtin__list_1_0));
Define_label(mercury____Compare___mercury_builtin__list_1_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_builtin__list_1_0));
	if (((Integer) detstackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mercury_builtin__list_1_0_i4);
	r1 = ((Integer) 1);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___mercury_builtin__list_1_0_i4);
	if (((Integer) detstackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___mercury_builtin__list_1_0_i6);
	r1 = ((Integer) 2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___mercury_builtin__list_1_0_i6);
	if (((Integer) detstackvar(1) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__list_1_0_i11);
	if (((Integer) detstackvar(2) != (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__list_1_0_i9);
	r1 = ((Integer) 0);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___mercury_builtin__list_1_0_i11);
	{
	Word tempr1, tempr2;
	tempr1 = (Integer) detstackvar(2);
	if (((Integer) tempr1 == (Integer) mkword(mktag(0), mkbody(((Integer) 0)))))
		GOTO_LABEL(mercury____Compare___mercury_builtin__list_1_0_i9);
	tempr2 = (Integer) detstackvar(1);
	r2 = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 0));
	r3 = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(1), (Integer) tempr2, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(1), (Integer) tempr1, ((Integer) 1));
	r1 = (Integer) detstackvar(4);
	{
	Declare_entry(mercury__compare_3_3);
	call_localret(ENTRY(mercury__compare_3_3),
		mercury____Compare___mercury_builtin__list_1_0_i16,
		ENTRY(mercury____Compare___mercury_builtin__list_1_0));
	}
	}
Define_label(mercury____Compare___mercury_builtin__list_1_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_builtin__list_1_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mercury_builtin__list_1_0_i15);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___mercury_builtin__list_1_0_i15);
	r1 = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	localtailcall(mercury____Compare___mercury_builtin__list_1_0,
		ENTRY(mercury____Compare___mercury_builtin__list_1_0));
Define_label(mercury____Compare___mercury_builtin__list_1_0_i9);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(5);
	decr_sp_pop_msg(5);
	{
		tailcall(STATIC(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___mercury_builtin__list_1_0));
	}
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module81)
	init_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	init_label(mercury____Unify___mercury_builtin__term__context_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mercury_builtin__term__context_0_0);
	if ((strcmp((char *)(Integer) field(mktag(0), (Integer) r1, ((Integer) 0)), (char *)(Integer) field(mktag(0), (Integer) r2, ((Integer) 0))) !=0))
		GOTO_LABEL(mercury____Unify___mercury_builtin__term__context_0_0_i1);
	if (((Integer) field(mktag(0), (Integer) r1, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r2, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mercury_builtin__term__context_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mercury_builtin__term__context_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module82)
	init_entry(mercury____Index___mercury_builtin__term__context_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mercury_builtin__term__context_0_0);
	tailcall(STATIC(mercury____Index___mercury_builtin_term__context_0__ua10000_2_0),
		ENTRY(mercury____Index___mercury_builtin__term__context_0_0));
END_MODULE

BEGIN_MODULE(mercury__mercury_builtin_module83)
	init_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	init_label(mercury____Compare___mercury_builtin__term__context_0_0_i4);
	init_label(mercury____Compare___mercury_builtin__term__context_0_0_i3);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mercury_builtin__term__context_0_0);
	incr_sp_push_msg(3, "__Compare__");
	detstackvar(3) = (Integer) succip;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	{
		call_localret(STATIC(mercury__builtin_compare_string_3_0),
		mercury____Compare___mercury_builtin__term__context_0_0_i4,
		ENTRY(mercury____Compare___mercury_builtin__term__context_0_0));
	}
Define_label(mercury____Compare___mercury_builtin__term__context_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___mercury_builtin__term__context_0_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mercury_builtin__term__context_0_0_i3);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Compare___mercury_builtin__term__context_0_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(2);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	{
		tailcall(STATIC(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mercury_builtin__term__context_0_0));
	}
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__mercury_builtin_bunch_0(void)
{
	mercury__mercury_builtin_module0();
	mercury__mercury_builtin_module1();
	mercury__mercury_builtin_module2();
	mercury__mercury_builtin_module3();
	mercury__mercury_builtin_module4();
	mercury__mercury_builtin_module5();
	mercury__mercury_builtin_module6();
	mercury__mercury_builtin_module7();
	mercury__mercury_builtin_module8();
	mercury__mercury_builtin_module9();
	mercury__mercury_builtin_module10();
	mercury__mercury_builtin_module11();
	mercury__mercury_builtin_module12();
	mercury__mercury_builtin_module13();
	mercury__mercury_builtin_module14();
	mercury__mercury_builtin_module15();
	mercury__mercury_builtin_module16();
	mercury__mercury_builtin_module17();
	mercury__mercury_builtin_module18();
	mercury__mercury_builtin_module19();
	mercury__mercury_builtin_module20();
	mercury__mercury_builtin_module21();
	mercury__mercury_builtin_module22();
	mercury__mercury_builtin_module23();
	mercury__mercury_builtin_module24();
	mercury__mercury_builtin_module25();
	mercury__mercury_builtin_module26();
	mercury__mercury_builtin_module27();
	mercury__mercury_builtin_module28();
	mercury__mercury_builtin_module29();
	mercury__mercury_builtin_module30();
	mercury__mercury_builtin_module31();
	mercury__mercury_builtin_module32();
	mercury__mercury_builtin_module33();
	mercury__mercury_builtin_module34();
	mercury__mercury_builtin_module35();
	mercury__mercury_builtin_module36();
	mercury__mercury_builtin_module37();
	mercury__mercury_builtin_module38();
	mercury__mercury_builtin_module39();
	mercury__mercury_builtin_module40();
}

static void mercury__mercury_builtin_bunch_1(void)
{
	mercury__mercury_builtin_module41();
	mercury__mercury_builtin_module42();
	mercury__mercury_builtin_module43();
	mercury__mercury_builtin_module44();
	mercury__mercury_builtin_module45();
	mercury__mercury_builtin_module46();
	mercury__mercury_builtin_module47();
	mercury__mercury_builtin_module48();
	mercury__mercury_builtin_module49();
	mercury__mercury_builtin_module50();
	mercury__mercury_builtin_module51();
	mercury__mercury_builtin_module52();
	mercury__mercury_builtin_module53();
	mercury__mercury_builtin_module54();
	mercury__mercury_builtin_module55();
	mercury__mercury_builtin_module56();
	mercury__mercury_builtin_module57();
	mercury__mercury_builtin_module58();
	mercury__mercury_builtin_module59();
	mercury__mercury_builtin_module60();
	mercury__mercury_builtin_module61();
	mercury__mercury_builtin_module62();
	mercury__mercury_builtin_module63();
	mercury__mercury_builtin_module64();
	mercury__mercury_builtin_module65();
	mercury__mercury_builtin_module66();
	mercury__mercury_builtin_module67();
	mercury__mercury_builtin_module68();
	mercury__mercury_builtin_module69();
	mercury__mercury_builtin_module70();
	mercury__mercury_builtin_module71();
	mercury__mercury_builtin_module72();
	mercury__mercury_builtin_module73();
	mercury__mercury_builtin_module74();
	mercury__mercury_builtin_module75();
	mercury__mercury_builtin_module76();
	mercury__mercury_builtin_module77();
	mercury__mercury_builtin_module78();
	mercury__mercury_builtin_module79();
	mercury__mercury_builtin_module80();
	mercury__mercury_builtin_module81();
}

static void mercury__mercury_builtin_bunch_2(void)
{
	mercury__mercury_builtin_module82();
	mercury__mercury_builtin_module83();
}

#endif

void mercury__mercury_builtin__init(void); /* suppress gcc warning */
void mercury__mercury_builtin__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__mercury_builtin_bunch_0();
	mercury__mercury_builtin_bunch_1();
	mercury__mercury_builtin_bunch_2();
#endif
}
