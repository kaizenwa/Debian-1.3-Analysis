/*
** Automatically generated from `graph.m' by the
** Mercury compiler, version 0.6.  Do not edit.
*/
/*
INIT mercury__graph__init
ENDINIT
*/

#include "imp.h"

Declare_static(mercury____Compare___graph_arc_info_2__ua10000_3_0);
Declare_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i4);
Declare_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i5);
Declare_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i3);
Declare_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i10);
Declare_static(mercury____Index___graph_arc_info_2__ua10000_2_0);
Declare_static(mercury____Unify___graph_arc_info_2__ua0_2_0);
Declare_label(mercury____Unify___graph_arc_info_2__ua0_2_0_i1003);
Declare_static(mercury____Index___graph_graph_1__ua10000_2_0);
Declare_static(mercury____Compare___graph_arc_1__ua10000_3_0);
Declare_static(mercury____Index___graph_arc_1__ua10000_2_0);
Declare_static(mercury____Unify___graph_arc_1__ua0_2_0);
Declare_label(mercury____Unify___graph_arc_1__ua0_2_0_i1);
Declare_static(mercury____Compare___graph_node_1__ua10000_3_0);
Declare_static(mercury____Index___graph_node_1__ua10000_2_0);
Declare_static(mercury____Unify___graph_node_1__ua0_2_0);
Declare_label(mercury____Unify___graph_node_1__ua0_2_0_i1);
Declare_static(mercury____Index___graph_graph_2__ua10000_2_0);
Declare_static(mercury__graph__path_2__ua40001_5_0);
Declare_label(mercury__graph__path_2__ua40001_5_0_i1005);
Declare_label(mercury__graph__path_2__ua40001_5_0_i5);
Declare_label(mercury__graph__path_2__ua40001_5_0_i8);
Declare_label(mercury__graph__path_2__ua40001_5_0_i4);
Declare_label(mercury__graph__path_2__ua40001_5_0_i10);
Declare_label(mercury__graph__path_2__ua40001_5_0_i13);
Declare_label(mercury__graph__path_2__ua40001_5_0_i15);
Declare_static(mercury__graph__path_2__ua40000_5_0);
Declare_label(mercury__graph__path_2__ua40000_5_0_i1005);
Declare_label(mercury__graph__path_2__ua40000_5_0_i5);
Declare_label(mercury__graph__path_2__ua40000_5_0_i8);
Declare_label(mercury__graph__path_2__ua40000_5_0_i4);
Declare_label(mercury__graph__path_2__ua40000_5_0_i10);
Declare_label(mercury__graph__path_2__ua40000_5_0_i13);
Declare_label(mercury__graph__path_2__ua40000_5_0_i15);
Declare_static(mercury__graph__path__ua40001_4_0);
Declare_label(mercury__graph__path__ua40001_4_0_i1);
Declare_static(mercury__graph__path__ua40000_4_0);
Declare_label(mercury__graph__path__ua40000_4_0_i1);
Declare_static(mercury__graph__nodes__ua10000_2_0);
Declare_label(mercury__graph__nodes__ua10000_2_0_i2);
Declare_static(mercury__graph__successors__ua10000_3_0);
Declare_label(mercury__graph__successors__ua10000_3_0_i2);
Declare_label(mercury__graph__successors__ua10000_3_0_i3);
Declare_static(mercury__graph__node_contents__ua10000_3_0);
Declare_static(mercury__graph__find_matching_nodes__ua10000_3_0);
Declare_label(mercury__graph__find_matching_nodes__ua10000_3_0_i2);
Declare_static(mercury__graph__search_node__ua40000_3_0);
Declare_label(mercury__graph__search_node__ua40000_3_0_i1);
Declare_label(mercury__graph__search_node__ua40000_3_0_i2);
Declare_static(mercury__graph__det_insert_node__ua10000_4_0);
Declare_label(mercury__graph__det_insert_node__ua10000_4_0_i4);
Declare_label(mercury__graph__det_insert_node__ua10000_4_0_i1000);
Declare_static(mercury__graph__insert_node__ua0_4_0);
Declare_label(mercury__graph__insert_node__ua0_4_0_i7);
Declare_label(mercury__graph__insert_node__ua0_4_0_i8);
Declare_label(mercury__graph__insert_node__ua0_4_0_i6);
Declare_label(mercury__graph__insert_node__ua0_4_0_i11);
Declare_label(mercury__graph__insert_node__ua0_4_0_i12);
Declare_label(mercury__graph__insert_node__ua0_4_0_i13);
Declare_static(mercury__graph__set_node__ua10000_4_0);
Declare_label(mercury__graph__set_node__ua10000_4_0_i2);
Declare_label(mercury__graph__set_node__ua10000_4_0_i3);
Declare_label(mercury__graph__set_node__ua10000_4_0_i4);
Declare_static(mercury__graph__LambdaGoal__1_4_0);
Declare_label(mercury__graph__LambdaGoal__1_4_0_i1);
Declare_label(mercury__graph__LambdaGoal__1_4_0_i2);
Define_extern_entry(mercury__graph__init_1_0);
Declare_label(mercury__graph__init_1_0_i2);
Declare_label(mercury__graph__init_1_0_i3);
Declare_label(mercury__graph__init_1_0_i4);
Define_extern_entry(mercury__graph__set_node_4_0);
Define_extern_entry(mercury__graph__insert_node_4_0);
Declare_label(mercury__graph__insert_node_4_0_i2);
Declare_label(mercury__graph__insert_node_4_0_i1000);
Define_extern_entry(mercury__graph__det_insert_node_4_0);
Define_extern_entry(mercury__graph__search_node_3_0);
Declare_label(mercury__graph__search_node_3_0_i1);
Define_extern_entry(mercury__graph__find_matching_nodes_3_0);
Define_extern_entry(mercury__graph__node_contents_3_0);
Define_extern_entry(mercury__graph__successors_3_0);
Define_extern_entry(mercury__graph__nodes_2_0);
Define_extern_entry(mercury__graph__set_edge_6_0);
Declare_label(mercury__graph__set_edge_6_0_i2);
Declare_label(mercury__graph__set_edge_6_0_i3);
Declare_label(mercury__graph__set_edge_6_0_i4);
Declare_label(mercury__graph__set_edge_6_0_i5);
Define_extern_entry(mercury__graph__insert_edge_6_0);
Declare_label(mercury__graph__insert_edge_6_0_i2);
Declare_label(mercury__graph__insert_edge_6_0_i4);
Declare_label(mercury__graph__insert_edge_6_0_i5);
Declare_label(mercury__graph__insert_edge_6_0_i6);
Declare_label(mercury__graph__insert_edge_6_0_i1);
Define_extern_entry(mercury__graph__det_insert_edge_6_0);
Declare_label(mercury__graph__det_insert_edge_6_0_i4);
Declare_label(mercury__graph__det_insert_edge_6_0_i1000);
Define_extern_entry(mercury__graph__arc_contents_5_0);
Declare_label(mercury__graph__arc_contents_5_0_i2);
Define_extern_entry(mercury__graph__path_4_0);
Declare_label(mercury__graph__path_4_0_i1);
Define_extern_entry(mercury__graph__path_4_1);
Declare_label(mercury__graph__path_4_1_i1);
Define_extern_entry(mercury____Unify___graph__graph_2_0);
Declare_label(mercury____Unify___graph__graph_2_0_i2);
Declare_label(mercury____Unify___graph__graph_2_0_i4);
Declare_label(mercury____Unify___graph__graph_2_0_i1005);
Declare_label(mercury____Unify___graph__graph_2_0_i1);
Define_extern_entry(mercury____Index___graph__graph_2_0);
Define_extern_entry(mercury____Compare___graph__graph_2_0);
Declare_label(mercury____Compare___graph__graph_2_0_i4);
Declare_label(mercury____Compare___graph__graph_2_0_i5);
Declare_label(mercury____Compare___graph__graph_2_0_i3);
Declare_label(mercury____Compare___graph__graph_2_0_i10);
Declare_label(mercury____Compare___graph__graph_2_0_i16);
Declare_label(mercury____Compare___graph__graph_2_0_i22);
Define_extern_entry(mercury____Unify___graph__node_1_0);
Define_extern_entry(mercury____Index___graph__node_1_0);
Define_extern_entry(mercury____Compare___graph__node_1_0);
Define_extern_entry(mercury____Unify___graph__arc_1_0);
Define_extern_entry(mercury____Index___graph__arc_1_0);
Define_extern_entry(mercury____Compare___graph__arc_1_0);
Define_extern_entry(mercury____Unify___graph__graph_1_0);
Define_extern_entry(mercury____Index___graph__graph_1_0);
Define_extern_entry(mercury____Compare___graph__graph_1_0);
Define_extern_entry(mercury____Unify___graph__arc_0_0);
Declare_label(mercury____Unify___graph__arc_0_0_i1);
Define_extern_entry(mercury____Index___graph__arc_0_0);
Define_extern_entry(mercury____Compare___graph__arc_0_0);
Declare_static(mercury____Unify___graph__arc_info_2_0);
Declare_static(mercury____Index___graph__arc_info_2_0);
Declare_static(mercury____Compare___graph__arc_info_2_0);

extern Word * mercury_data_graph__base_type_layout_arc_0[];
Word * mercury_data_graph__base_type_info_arc_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury____Unify___graph__arc_0_0),
	(Word *) (Integer) ENTRY(mercury____Index___graph__arc_0_0),
	(Word *) (Integer) ENTRY(mercury____Compare___graph__arc_0_0),
	(Word *) (Integer) mercury_data_graph__base_type_layout_arc_0
};

extern Word * mercury_data_graph__base_type_layout_arc_1[];
Word * mercury_data_graph__base_type_info_arc_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___graph__arc_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___graph__arc_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___graph__arc_1_0),
	(Word *) (Integer) mercury_data_graph__base_type_layout_arc_1
};

extern Word * mercury_data_graph__base_type_layout_arc_info_2[];
Word * mercury_data_graph__base_type_info_arc_info_2[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) STATIC(mercury____Unify___graph__arc_info_2_0),
	(Word *) (Integer) STATIC(mercury____Index___graph__arc_info_2_0),
	(Word *) (Integer) STATIC(mercury____Compare___graph__arc_info_2_0),
	(Word *) (Integer) mercury_data_graph__base_type_layout_arc_info_2
};

extern Word * mercury_data_graph__base_type_layout_graph_1[];
Word * mercury_data_graph__base_type_info_graph_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___graph__graph_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___graph__graph_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___graph__graph_1_0),
	(Word *) (Integer) mercury_data_graph__base_type_layout_graph_1
};

extern Word * mercury_data_graph__base_type_layout_graph_2[];
Word * mercury_data_graph__base_type_info_graph_2[] = {
	(Word *) ((Integer) 2),
	(Word *) (Integer) ENTRY(mercury____Unify___graph__graph_2_0),
	(Word *) (Integer) ENTRY(mercury____Index___graph__graph_2_0),
	(Word *) (Integer) ENTRY(mercury____Compare___graph__graph_2_0),
	(Word *) (Integer) mercury_data_graph__base_type_layout_graph_2
};

Declare_entry(mercury__unused_0_0);
extern Word * mercury_data_graph__base_type_layout_graph__arc_supply_0[];
Word * mercury_data_graph__base_type_info_graph__arc_supply_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_graph__base_type_layout_graph__arc_supply_0
};

extern Word * mercury_data_graph__base_type_layout_graph__node_supply_0[];
Word * mercury_data_graph__base_type_info_graph__node_supply_0[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) ENTRY(mercury__unused_0_0),
	(Word *) (Integer) mercury_data_graph__base_type_layout_graph__node_supply_0
};

extern Word * mercury_data_graph__base_type_layout_node_1[];
Word * mercury_data_graph__base_type_info_node_1[] = {
	(Word *) ((Integer) 1),
	(Word *) (Integer) ENTRY(mercury____Unify___graph__node_1_0),
	(Word *) (Integer) ENTRY(mercury____Index___graph__node_1_0),
	(Word *) (Integer) ENTRY(mercury____Compare___graph__node_1_0),
	(Word *) (Integer) mercury_data_graph__base_type_layout_node_1
};

extern Word * mercury_data_graph__common_2[];
Word * mercury_data_graph__base_type_layout_node_1[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2)
};

Word * mercury_data_graph__base_type_layout_graph__node_supply_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2)
};

Word * mercury_data_graph__base_type_layout_graph__arc_supply_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2)
};

extern Word * mercury_data_graph__common_7[];
Word * mercury_data_graph__base_type_layout_graph_2[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_graph__common_7),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

extern Word * mercury_data_graph__common_9[];
Word * mercury_data_graph__base_type_layout_graph_1[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_9),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_9)
};

extern Word * mercury_data_graph__common_10[];
Word * mercury_data_graph__base_type_layout_arc_info_2[] = {
	(Word *) (Integer) mkword(mktag(1), (Integer) mercury_data_graph__common_10),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1))),
	(Word *) (Integer) mkword(mktag(0), mkbody(((Integer) 1)))
};

Word * mercury_data_graph__base_type_layout_arc_1[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2)
};

Word * mercury_data_graph__base_type_layout_arc_0[] = {
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2),
	(Word *) (Integer) mkword(mktag(3), (Integer) mercury_data_graph__common_2)
};

extern Word * mercury_data_tree234__base_type_info_tree234_2[];
extern Word * mercury_data___base_type_info_int_0[];
Word * mercury_data_graph__common_0[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_graph__common_1[] = {
	(Word *) (Integer) mercury_data___base_type_info_int_0
};

Word * mercury_data_graph__common_2[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_1)
};

Word * mercury_data_graph__common_3[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) ((Integer) 1)
};

Word * mercury_data_graph__common_4[] = {
	(Word *) (Integer) mercury_data_graph__base_type_info_arc_info_2,
	(Word *) ((Integer) 1),
	(Word *) ((Integer) 2)
};

Word * mercury_data_graph__common_5[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_4)
};

Word * mercury_data_graph__common_6[] = {
	(Word *) (Integer) mercury_data_tree234__base_type_info_tree234_2,
	(Word *) (Integer) mercury_data___base_type_info_int_0,
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0)
};

Word * mercury_data_graph__common_7[] = {
	(Word *) ((Integer) 5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_5),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_6),
	(Word *) string_const("graph", 5)
};

extern Word * mercury_data_std_util__base_type_info_unit_0[];
Word * mercury_data_graph__common_8[] = {
	(Word *) (Integer) mercury_data_graph__base_type_info_graph_2,
	(Word *) ((Integer) 1),
	(Word *) (Integer) mercury_data_std_util__base_type_info_unit_0
};

Word * mercury_data_graph__common_9[] = {
	(Word *) ((Integer) 0),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_8)
};

Word * mercury_data_graph__common_10[] = {
	(Word *) ((Integer) 3),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_1),
	(Word *) (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_1),
	(Word *) ((Integer) 2),
	(Word *) string_const("arc_info", 8)
};

BEGIN_MODULE(mercury__graph_module0)
	init_entry(mercury____Compare___graph_arc_info_2__ua10000_3_0);
	init_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i4);
	init_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i5);
	init_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i3);
	init_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i10);
BEGIN_CODE

/* code for predicate '__Compare___graph_arc_info_2__ua10000'/3 in mode 0 */
Define_static(mercury____Compare___graph_arc_info_2__ua10000_3_0);
	incr_sp_push_msg(6, "__Compare___graph_arc_info_2__ua10000");
	detstackvar(6) = (Integer) succip;
	detstackvar(5) = (Integer) r1;
	r1 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___graph_arc_info_2__ua10000_3_0_i4,
		STATIC(mercury____Compare___graph_arc_info_2__ua10000_3_0));
	}
Define_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___graph_arc_info_2__ua10000_3_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___graph_arc_info_2__ua10000_3_0_i3);
Define_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
Define_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___graph_arc_info_2__ua10000_3_0_i10,
		STATIC(mercury____Compare___graph_arc_info_2__ua10000_3_0));
	}
Define_label(mercury____Compare___graph_arc_info_2__ua10000_3_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___graph_arc_info_2__ua10000_3_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___graph_arc_info_2__ua10000_3_0_i5);
	r1 = (Integer) detstackvar(5);
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	{
	Declare_entry(mercury__compare_3_3);
	tailcall(ENTRY(mercury__compare_3_3),
		STATIC(mercury____Compare___graph_arc_info_2__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module1)
	init_entry(mercury____Index___graph_arc_info_2__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___graph_arc_info_2__ua10000'/2 in mode 0 */
Define_static(mercury____Index___graph_arc_info_2__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__graph_module2)
	init_entry(mercury____Unify___graph_arc_info_2__ua0_2_0);
	init_label(mercury____Unify___graph_arc_info_2__ua0_2_0_i1003);
BEGIN_CODE

/* code for predicate '__Unify___graph_arc_info_2__ua0'/2 in mode 0 */
Define_static(mercury____Unify___graph_arc_info_2__ua0_2_0);
	if (((Integer) field(mktag(0), (Integer) r2, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r3, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___graph_arc_info_2__ua0_2_0_i1003);
	if (((Integer) field(mktag(0), (Integer) r2, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r3, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___graph_arc_info_2__ua0_2_0_i1003);
	r3 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	r2 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	{
	Declare_entry(mercury__unify_2_0);
	tailcall(ENTRY(mercury__unify_2_0),
		STATIC(mercury____Unify___graph_arc_info_2__ua0_2_0));
	}
Define_label(mercury____Unify___graph_arc_info_2__ua0_2_0_i1003);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__graph_module3)
	init_entry(mercury____Index___graph_graph_1__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___graph_graph_1__ua10000'/2 in mode 0 */
Define_static(mercury____Index___graph_graph_1__ua10000_2_0);
	tailcall(STATIC(mercury____Index___graph_graph_2__ua10000_2_0),
		STATIC(mercury____Index___graph_graph_1__ua10000_2_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module4)
	init_entry(mercury____Compare___graph_arc_1__ua10000_3_0);
BEGIN_CODE

/* code for predicate '__Compare___graph_arc_1__ua10000'/3 in mode 0 */
Define_static(mercury____Compare___graph_arc_1__ua10000_3_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___graph_arc_1__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module5)
	init_entry(mercury____Index___graph_arc_1__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___graph_arc_1__ua10000'/2 in mode 0 */
Define_static(mercury____Index___graph_arc_1__ua10000_2_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		STATIC(mercury____Index___graph_arc_1__ua10000_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module6)
	init_entry(mercury____Unify___graph_arc_1__ua0_2_0);
	init_label(mercury____Unify___graph_arc_1__ua0_2_0_i1);
BEGIN_CODE

/* code for predicate '__Unify___graph_arc_1__ua0'/2 in mode 0 */
Define_static(mercury____Unify___graph_arc_1__ua0_2_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___graph_arc_1__ua0_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___graph_arc_1__ua0_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__graph_module7)
	init_entry(mercury____Compare___graph_node_1__ua10000_3_0);
BEGIN_CODE

/* code for predicate '__Compare___graph_node_1__ua10000'/3 in mode 0 */
Define_static(mercury____Compare___graph_node_1__ua10000_3_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___graph_node_1__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module8)
	init_entry(mercury____Index___graph_node_1__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___graph_node_1__ua10000'/2 in mode 0 */
Define_static(mercury____Index___graph_node_1__ua10000_2_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		STATIC(mercury____Index___graph_node_1__ua10000_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module9)
	init_entry(mercury____Unify___graph_node_1__ua0_2_0);
	init_label(mercury____Unify___graph_node_1__ua0_2_0_i1);
BEGIN_CODE

/* code for predicate '__Unify___graph_node_1__ua0'/2 in mode 0 */
Define_static(mercury____Unify___graph_node_1__ua0_2_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___graph_node_1__ua0_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___graph_node_1__ua0_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__graph_module10)
	init_entry(mercury____Index___graph_graph_2__ua10000_2_0);
BEGIN_CODE

/* code for predicate '__Index___graph_graph_2__ua10000'/2 in mode 0 */
Define_static(mercury____Index___graph_graph_2__ua10000_2_0);
	r1 = ((Integer) 0);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__graph_module11)
	init_entry(mercury__graph__path_2__ua40001_5_0);
	init_label(mercury__graph__path_2__ua40001_5_0_i1005);
	init_label(mercury__graph__path_2__ua40001_5_0_i5);
	init_label(mercury__graph__path_2__ua40001_5_0_i8);
	init_label(mercury__graph__path_2__ua40001_5_0_i4);
	init_label(mercury__graph__path_2__ua40001_5_0_i10);
	init_label(mercury__graph__path_2__ua40001_5_0_i13);
	init_label(mercury__graph__path_2__ua40001_5_0_i15);
BEGIN_CODE

/* code for predicate 'graph__path_2__ua40001'/5 in mode 0 */
Define_static(mercury__graph__path_2__ua40001_5_0);
	{
	Declare_entry(do_fail);
	mkframe("graph__path_2__ua40001/5", 5, ENTRY(do_fail));
	}
	framevar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r4 = (Integer) r2;
	framevar(0) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__graph__path_2__ua40001_5_0_i1005,
		STATIC(mercury__graph__path_2__ua40001_5_0));
	}
Define_label(mercury__graph__path_2__ua40001_5_0_i1005);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40001_5_0));
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__graph__path_2__ua40001_5_0_i4);
	r3 = (Integer) r1;
	framevar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__member_3_0);
	call_localret(ENTRY(mercury__map__member_3_0),
		mercury__graph__path_2__ua40001_5_0_i5,
		STATIC(mercury__graph__path_2__ua40001_5_0));
	}
Define_label(mercury__graph__path_2__ua40001_5_0_i5);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40001_5_0));
	framevar(1) = (Integer) r2;
	framevar(4) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) framevar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__graph__path_2__ua40001_5_0_i8,
		STATIC(mercury__graph__path_2__ua40001_5_0));
	}
Define_label(mercury__graph__path_2__ua40001_5_0_i8);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40001_5_0));
	{
	Declare_entry(do_redo);
	if ((Integer) r1)
		GOTO(ENTRY(do_redo));
	}
	r1 = (Integer) framevar(1);
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) framevar(4);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	succeed();
Define_label(mercury__graph__path_2__ua40001_5_0_i4);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40001_5_0));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) framevar(3);
	{
	Declare_entry(mercury__map__member_3_0);
	call_localret(ENTRY(mercury__map__member_3_0),
		mercury__graph__path_2__ua40001_5_0_i10,
		STATIC(mercury__graph__path_2__ua40001_5_0));
	}
Define_label(mercury__graph__path_2__ua40001_5_0_i10);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40001_5_0));
	framevar(1) = (Integer) r2;
	framevar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) framevar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__graph__path_2__ua40001_5_0_i13,
		STATIC(mercury__graph__path_2__ua40001_5_0));
	}
Define_label(mercury__graph__path_2__ua40001_5_0_i13);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40001_5_0));
	{
	Declare_entry(do_redo);
	if ((Integer) r1)
		GOTO(ENTRY(do_redo));
	}
	r1 = (Integer) framevar(0);
	r2 = (Integer) framevar(1);
	tag_incr_hp(r3, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r3, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r3, ((Integer) 1)) = (Integer) framevar(2);
	localcall(mercury__graph__path_2__ua40001_5_0,
		LABEL(mercury__graph__path_2__ua40001_5_0_i15),
		STATIC(mercury__graph__path_2__ua40001_5_0));
Define_label(mercury__graph__path_2__ua40001_5_0_i15);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40001_5_0));
	r3 = (Integer) r2;
	tag_incr_hp(r2, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r2, ((Integer) 0)) = (Integer) framevar(3);
	field(mktag(1), (Integer) r2, ((Integer) 1)) = (Integer) r3;
	succeed();
END_MODULE

BEGIN_MODULE(mercury__graph_module12)
	init_entry(mercury__graph__path_2__ua40000_5_0);
	init_label(mercury__graph__path_2__ua40000_5_0_i1005);
	init_label(mercury__graph__path_2__ua40000_5_0_i5);
	init_label(mercury__graph__path_2__ua40000_5_0_i8);
	init_label(mercury__graph__path_2__ua40000_5_0_i4);
	init_label(mercury__graph__path_2__ua40000_5_0_i10);
	init_label(mercury__graph__path_2__ua40000_5_0_i13);
	init_label(mercury__graph__path_2__ua40000_5_0_i15);
BEGIN_CODE

/* code for predicate 'graph__path_2__ua40000'/5 in mode 0 */
Define_static(mercury__graph__path_2__ua40000_5_0);
	{
	Declare_entry(do_fail);
	mkframe("graph__path_2__ua40000/5", 5, ENTRY(do_fail));
	}
	framevar(1) = (Integer) r3;
	framevar(2) = (Integer) r4;
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r4 = (Integer) r2;
	framevar(0) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__graph__path_2__ua40000_5_0_i1005,
		STATIC(mercury__graph__path_2__ua40000_5_0));
	}
Define_label(mercury__graph__path_2__ua40000_5_0_i1005);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40000_5_0));
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__graph__path_2__ua40000_5_0_i4);
	r3 = (Integer) r1;
	framevar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__member_3_0);
	call_localret(ENTRY(mercury__map__member_3_0),
		mercury__graph__path_2__ua40000_5_0_i5,
		STATIC(mercury__graph__path_2__ua40000_5_0));
	}
Define_label(mercury__graph__path_2__ua40000_5_0_i5);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40000_5_0));
	{
	Declare_entry(do_redo);
	if (((Integer) framevar(1) != (Integer) r2))
		GOTO(ENTRY(do_redo));
	}
	framevar(4) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) framevar(1);
	r3 = (Integer) framevar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__graph__path_2__ua40000_5_0_i8,
		STATIC(mercury__graph__path_2__ua40000_5_0));
	}
Define_label(mercury__graph__path_2__ua40000_5_0_i8);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40000_5_0));
	{
	Declare_entry(do_redo);
	if ((Integer) r1)
		GOTO(ENTRY(do_redo));
	}
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) framevar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	succeed();
Define_label(mercury__graph__path_2__ua40000_5_0_i4);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40000_5_0));
	{
	Declare_entry(do_fail);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) ENTRY(do_fail);
	}
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) framevar(3);
	{
	Declare_entry(mercury__map__member_3_0);
	call_localret(ENTRY(mercury__map__member_3_0),
		mercury__graph__path_2__ua40000_5_0_i10,
		STATIC(mercury__graph__path_2__ua40000_5_0));
	}
Define_label(mercury__graph__path_2__ua40000_5_0_i10);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40000_5_0));
	framevar(3) = (Integer) r2;
	framevar(4) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r3 = (Integer) framevar(2);
	{
	Declare_entry(mercury__list__member_2_0);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__graph__path_2__ua40000_5_0_i13,
		STATIC(mercury__graph__path_2__ua40000_5_0));
	}
Define_label(mercury__graph__path_2__ua40000_5_0_i13);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40000_5_0));
	{
	Declare_entry(do_redo);
	if ((Integer) r1)
		GOTO(ENTRY(do_redo));
	}
	r1 = (Integer) framevar(0);
	r2 = (Integer) framevar(3);
	r3 = (Integer) framevar(1);
	tag_incr_hp(r4, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r4, ((Integer) 0)) = (Integer) r2;
	field(mktag(1), (Integer) r4, ((Integer) 1)) = (Integer) framevar(2);
	localcall(mercury__graph__path_2__ua40000_5_0,
		LABEL(mercury__graph__path_2__ua40000_5_0_i15),
		STATIC(mercury__graph__path_2__ua40000_5_0));
Define_label(mercury__graph__path_2__ua40000_5_0_i15);
	update_prof_current_proc(LABEL(mercury__graph__path_2__ua40000_5_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(1), ((Integer) 2));
	field(mktag(1), (Integer) r1, ((Integer) 0)) = (Integer) framevar(4);
	field(mktag(1), (Integer) r1, ((Integer) 1)) = (Integer) r2;
	succeed();
END_MODULE

BEGIN_MODULE(mercury__graph_module13)
	init_entry(mercury__graph__path__ua40001_4_0);
	init_label(mercury__graph__path__ua40001_4_0_i1);
BEGIN_CODE

/* code for predicate 'graph__path__ua40001'/4 in mode 0 */
Define_static(mercury__graph__path__ua40001_4_0);
	{
	Declare_entry(do_fail);
	mkframe("graph__path__ua40001/4", 1, ENTRY(do_fail));
	}
	r3 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__graph__path_2__ua40001_5_0),
		mercury__graph__path__ua40001_4_0_i1,
		STATIC(mercury__graph__path__ua40001_4_0));
Define_label(mercury__graph__path__ua40001_4_0_i1);
	update_prof_current_proc(LABEL(mercury__graph__path__ua40001_4_0));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__graph_module14)
	init_entry(mercury__graph__path__ua40000_4_0);
	init_label(mercury__graph__path__ua40000_4_0_i1);
BEGIN_CODE

/* code for predicate 'graph__path__ua40000'/4 in mode 0 */
Define_static(mercury__graph__path__ua40000_4_0);
	{
	Declare_entry(do_fail);
	mkframe("graph__path__ua40000/4", 1, ENTRY(do_fail));
	}
	r4 = (Integer) mkword(mktag(0), mkbody(((Integer) 0)));
	call_localret(STATIC(mercury__graph__path_2__ua40000_5_0),
		mercury__graph__path__ua40000_4_0_i1,
		STATIC(mercury__graph__path__ua40000_4_0));
Define_label(mercury__graph__path__ua40000_4_0_i1);
	update_prof_current_proc(LABEL(mercury__graph__path__ua40000_4_0));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__graph_module15)
	init_entry(mercury__graph__nodes__ua10000_2_0);
	init_label(mercury__graph__nodes__ua10000_2_0_i2);
BEGIN_CODE

/* code for predicate 'graph__nodes__ua10000'/2 in mode 0 */
Define_static(mercury__graph__nodes__ua10000_2_0);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	incr_sp_push_msg(1, "graph__nodes__ua10000");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__keys_2_0);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__graph__nodes__ua10000_2_0_i2,
		STATIC(mercury__graph__nodes__ua10000_2_0));
	}
Define_label(mercury__graph__nodes__ua10000_2_0_i2);
	update_prof_current_proc(LABEL(mercury__graph__nodes__ua10000_2_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	tailcall(ENTRY(mercury__set__list_to_set_2_0),
		STATIC(mercury__graph__nodes__ua10000_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module16)
	init_entry(mercury__graph__successors__ua10000_3_0);
	init_label(mercury__graph__successors__ua10000_3_0_i2);
	init_label(mercury__graph__successors__ua10000_3_0_i3);
BEGIN_CODE

/* code for predicate 'graph__successors__ua10000'/3 in mode 0 */
Define_static(mercury__graph__successors__ua10000_3_0);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	r4 = (Integer) r2;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	incr_sp_push_msg(1, "graph__successors__ua10000");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__graph__successors__ua10000_3_0_i2,
		STATIC(mercury__graph__successors__ua10000_3_0));
	}
Define_label(mercury__graph__successors__ua10000_3_0_i2);
	update_prof_current_proc(LABEL(mercury__graph__successors__ua10000_3_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__values_2_0);
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__graph__successors__ua10000_3_0_i3,
		STATIC(mercury__graph__successors__ua10000_3_0));
	}
Define_label(mercury__graph__successors__ua10000_3_0_i3);
	update_prof_current_proc(LABEL(mercury__graph__successors__ua10000_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__set__list_to_set_2_0);
	tailcall(ENTRY(mercury__set__list_to_set_2_0),
		STATIC(mercury__graph__successors__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module17)
	init_entry(mercury__graph__node_contents__ua10000_3_0);
BEGIN_CODE

/* code for predicate 'graph__node_contents__ua10000'/3 in mode 0 */
Define_static(mercury__graph__node_contents__ua10000_3_0);
	r4 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__lookup_3_1);
	tailcall(ENTRY(mercury__map__lookup_3_1),
		STATIC(mercury__graph__node_contents__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module18)
	init_entry(mercury__graph__find_matching_nodes__ua10000_3_0);
	init_label(mercury__graph__find_matching_nodes__ua10000_3_0_i2);
BEGIN_CODE

/* code for predicate 'graph__find_matching_nodes__ua10000'/3 in mode 0 */
Define_static(mercury__graph__find_matching_nodes__ua10000_3_0);
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	tag_incr_hp(r2, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) STATIC(mercury__graph__LambdaGoal__1_4_0);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = ((Integer) 3);
	incr_sp_push_msg(1, "graph__find_matching_nodes__ua10000");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__std_util__solutions_2_1);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__graph__find_matching_nodes__ua10000_3_0_i2,
		STATIC(mercury__graph__find_matching_nodes__ua10000_3_0));
	}
	}
Define_label(mercury__graph__find_matching_nodes__ua10000_3_0_i2);
	update_prof_current_proc(LABEL(mercury__graph__find_matching_nodes__ua10000_3_0));
	r2 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	{
	Declare_entry(mercury__set__sorted_list_to_set_2_0);
	tailcall(ENTRY(mercury__set__sorted_list_to_set_2_0),
		STATIC(mercury__graph__find_matching_nodes__ua10000_3_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module19)
	init_entry(mercury__graph__search_node__ua40000_3_0);
	init_label(mercury__graph__search_node__ua40000_3_0_i1);
	init_label(mercury__graph__search_node__ua40000_3_0_i2);
BEGIN_CODE

/* code for predicate 'graph__search_node__ua40000'/3 in mode 0 */
Define_static(mercury__graph__search_node__ua40000_3_0);
	{
	Declare_entry(do_fail);
	mkframe("graph__search_node__ua40000/3", 3, ENTRY(do_fail));
	}
	framevar(0) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	r2 = (Integer) r1;
	framevar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__member_3_0);
	call_localret(ENTRY(mercury__map__member_3_0),
		mercury__graph__search_node__ua40000_3_0_i1,
		STATIC(mercury__graph__search_node__ua40000_3_0));
	}
Define_label(mercury__graph__search_node__ua40000_3_0_i1);
	update_prof_current_proc(LABEL(mercury__graph__search_node__ua40000_3_0));
	r3 = (Integer) r2;
	framevar(1) = (Integer) r1;
	r1 = (Integer) framevar(2);
	r2 = (Integer) framevar(0);
	{
	Declare_entry(mercury__unify_2_0);
	call_localret(ENTRY(mercury__unify_2_0),
		mercury__graph__search_node__ua40000_3_0_i2,
		STATIC(mercury__graph__search_node__ua40000_3_0));
	}
Define_label(mercury__graph__search_node__ua40000_3_0_i2);
	update_prof_current_proc(LABEL(mercury__graph__search_node__ua40000_3_0));
	{
	Declare_entry(do_redo);
	if (!((Integer) r1))
		GOTO(ENTRY(do_redo));
	}
	r1 = (Integer) framevar(1);
	succeed();
END_MODULE

BEGIN_MODULE(mercury__graph_module20)
	init_entry(mercury__graph__det_insert_node__ua10000_4_0);
	init_label(mercury__graph__det_insert_node__ua10000_4_0_i4);
	init_label(mercury__graph__det_insert_node__ua10000_4_0_i1000);
BEGIN_CODE

/* code for predicate 'graph__det_insert_node__ua10000'/4 in mode 0 */
Define_static(mercury__graph__det_insert_node__ua10000_4_0);
	incr_sp_push_msg(1, "graph__det_insert_node__ua10000");
	detstackvar(1) = (Integer) succip;
	call_localret(STATIC(mercury__graph__insert_node__ua0_4_0),
		mercury__graph__det_insert_node__ua10000_4_0_i4,
		STATIC(mercury__graph__det_insert_node__ua10000_4_0));
Define_label(mercury__graph__det_insert_node__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__graph__det_insert_node__ua10000_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__graph__det_insert_node__ua10000_4_0_i1000);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
Define_label(mercury__graph__det_insert_node__ua10000_4_0_i1000);
	r1 = string_const("graph__det_insert_node: node already exists.", 44);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__graph__det_insert_node__ua10000_4_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module21)
	init_entry(mercury__graph__insert_node__ua0_4_0);
	init_label(mercury__graph__insert_node__ua0_4_0_i7);
	init_label(mercury__graph__insert_node__ua0_4_0_i8);
	init_label(mercury__graph__insert_node__ua0_4_0_i6);
	init_label(mercury__graph__insert_node__ua0_4_0_i11);
	init_label(mercury__graph__insert_node__ua0_4_0_i12);
	init_label(mercury__graph__insert_node__ua0_4_0_i13);
BEGIN_CODE

/* code for predicate 'graph__insert_node__ua0'/4 in mode 0 */
Define_static(mercury__graph__insert_node__ua0_4_0);
	incr_sp_push_msg(7, "graph__insert_node__ua0");
	detstackvar(7) = (Integer) succip;
	detstackvar(4) = (Integer) curfr;
	detstackvar(5) = (Integer) maxfr;
	detstackvar(6) = (Integer) bt_redoip((Integer) maxfr);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) LABEL(mercury__graph__insert_node__ua0_4_0_i6);
	detstackvar(2) = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(3) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__member_3_0);
	call_localret(ENTRY(mercury__map__member_3_0),
		mercury__graph__insert_node__ua0_4_0_i7,
		STATIC(mercury__graph__insert_node__ua0_4_0));
	}
Define_label(mercury__graph__insert_node__ua0_4_0_i7);
	update_prof_current_proc(LABEL(mercury__graph__insert_node__ua0_4_0));
	r3 = (Integer) r2;
	r1 = (Integer) detstackvar(3);
	r2 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__unify_2_0);
	call_localret(ENTRY(mercury__unify_2_0),
		mercury__graph__insert_node__ua0_4_0_i8,
		STATIC(mercury__graph__insert_node__ua0_4_0));
	}
Define_label(mercury__graph__insert_node__ua0_4_0_i8);
	update_prof_current_proc(LABEL(mercury__graph__insert_node__ua0_4_0));
	{
	Declare_entry(do_redo);
	if (!((Integer) r1))
		GOTO(ENTRY(do_redo));
	}
	LVALUE_CAST(Word,maxfr) = (Integer) detstackvar(5);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(6);
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(4);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__graph__insert_node__ua0_4_0_i6);
	update_prof_current_proc(LABEL(mercury__graph__insert_node__ua0_4_0));
	LVALUE_CAST(Word,curfr) = (Integer) detstackvar(4);
	r2 = (Integer) detstackvar(1);
	r3 = (Integer) detstackvar(2);
	r1 = (Integer) detstackvar(3);
	LVALUE_CAST(Word,bt_redoip((Integer) maxfr)) = (Integer) detstackvar(6);
	detstackvar(1) = ((Integer) field(mktag(0), (Integer) r2, ((Integer) 0)) + ((Integer) 1));
	r4 = (Integer) detstackvar(1);
	r5 = (Integer) r3;
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) tempr1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__graph__insert_node__ua0_4_0_i11,
		STATIC(mercury__graph__insert_node__ua0_4_0));
	}
	}
Define_label(mercury__graph__insert_node__ua0_4_0_i11);
	update_prof_current_proc(LABEL(mercury__graph__insert_node__ua0_4_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	detstackvar(2) = (Integer) tempr1;
	detstackvar(3) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__graph__insert_node__ua0_4_0_i12,
		STATIC(mercury__graph__insert_node__ua0_4_0));
	}
	}
Define_label(mercury__graph__insert_node__ua0_4_0_i12);
	update_prof_current_proc(LABEL(mercury__graph__insert_node__ua0_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__graph__insert_node__ua0_4_0_i13,
		STATIC(mercury__graph__insert_node__ua0_4_0));
	}
Define_label(mercury__graph__insert_node__ua0_4_0_i13);
	update_prof_current_proc(LABEL(mercury__graph__insert_node__ua0_4_0));
	r2 = (Integer) detstackvar(1);
	tag_incr_hp(r3, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r3, ((Integer) 4)) = (Integer) r1;
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module22)
	init_entry(mercury__graph__set_node__ua10000_4_0);
	init_label(mercury__graph__set_node__ua10000_4_0_i2);
	init_label(mercury__graph__set_node__ua10000_4_0_i3);
	init_label(mercury__graph__set_node__ua10000_4_0_i4);
BEGIN_CODE

/* code for predicate 'graph__set_node__ua10000'/4 in mode 0 */
Define_static(mercury__graph__set_node__ua10000_4_0);
	r5 = (Integer) r3;
	r4 = ((Integer) field(mktag(0), (Integer) r2, ((Integer) 0)) + ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r3;
	incr_sp_push_msg(4, "graph__set_node__ua10000");
	detstackvar(4) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) r4;
	r2 = (Integer) r1;
	detstackvar(2) = (Integer) tempr1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__graph__set_node__ua10000_4_0_i2,
		STATIC(mercury__graph__set_node__ua10000_4_0));
	}
	}
Define_label(mercury__graph__set_node__ua10000_4_0_i2);
	update_prof_current_proc(LABEL(mercury__graph__set_node__ua10000_4_0));
	r2 = (Integer) detstackvar(2);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	detstackvar(2) = (Integer) tempr1;
	detstackvar(3) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 3));
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__graph__set_node__ua10000_4_0_i3,
		STATIC(mercury__graph__set_node__ua10000_4_0));
	}
	}
Define_label(mercury__graph__set_node__ua10000_4_0_i3);
	update_prof_current_proc(LABEL(mercury__graph__set_node__ua10000_4_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__graph__set_node__ua10000_4_0_i4,
		STATIC(mercury__graph__set_node__ua10000_4_0));
	}
Define_label(mercury__graph__set_node__ua10000_4_0_i4);
	update_prof_current_proc(LABEL(mercury__graph__set_node__ua10000_4_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(1);
	tag_incr_hp(r2, mktag(0), ((Integer) 5));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(4);
	decr_sp_pop_msg(4);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module23)
	init_entry(mercury__graph__LambdaGoal__1_4_0);
	init_label(mercury__graph__LambdaGoal__1_4_0_i1);
	init_label(mercury__graph__LambdaGoal__1_4_0_i2);
BEGIN_CODE

/* code for predicate 'graph__LambdaGoal__1'/4 in mode 0 */
Define_static(mercury__graph__LambdaGoal__1_4_0);
	{
	Declare_entry(do_fail);
	mkframe("graph__LambdaGoal__1/4", 3, ENTRY(do_fail));
	}
	framevar(2) = (Integer) r3;
	{
	Word tempr1;
	tempr1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) tempr1;
	framevar(0) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__member_3_0);
	call_localret(ENTRY(mercury__map__member_3_0),
		mercury__graph__LambdaGoal__1_4_0_i1,
		STATIC(mercury__graph__LambdaGoal__1_4_0));
	}
	}
Define_label(mercury__graph__LambdaGoal__1_4_0_i1);
	update_prof_current_proc(LABEL(mercury__graph__LambdaGoal__1_4_0));
	r3 = (Integer) r2;
	framevar(1) = (Integer) r1;
	r1 = (Integer) framevar(2);
	r2 = (Integer) framevar(0);
	{
	Declare_entry(mercury__unify_2_0);
	call_localret(ENTRY(mercury__unify_2_0),
		mercury__graph__LambdaGoal__1_4_0_i2,
		STATIC(mercury__graph__LambdaGoal__1_4_0));
	}
Define_label(mercury__graph__LambdaGoal__1_4_0_i2);
	update_prof_current_proc(LABEL(mercury__graph__LambdaGoal__1_4_0));
	{
	Declare_entry(do_redo);
	if (!((Integer) r1))
		GOTO(ENTRY(do_redo));
	}
	r1 = (Integer) framevar(1);
	succeed();
END_MODULE

BEGIN_MODULE(mercury__graph_module24)
	init_entry(mercury__graph__init_1_0);
	init_label(mercury__graph__init_1_0_i2);
	init_label(mercury__graph__init_1_0_i3);
	init_label(mercury__graph__init_1_0_i4);
BEGIN_CODE

/* code for predicate 'graph__init'/1 in mode 0 */
Define_entry(mercury__graph__init_1_0);
	incr_sp_push_msg(3, "graph__init");
	detstackvar(3) = (Integer) succip;
	detstackvar(2) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__graph__init_1_0_i2,
		ENTRY(mercury__graph__init_1_0));
	}
Define_label(mercury__graph__init_1_0_i2);
	update_prof_current_proc(LABEL(mercury__graph__init_1_0));
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(1);
	detstackvar(1) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_graph__base_type_info_arc_info_2;
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__graph__init_1_0_i3,
		ENTRY(mercury__graph__init_1_0));
	}
Define_label(mercury__graph__init_1_0_i3);
	update_prof_current_proc(LABEL(mercury__graph__init_1_0));
	detstackvar(2) = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	{
	Declare_entry(mercury__map__init_1_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__graph__init_1_0_i4,
		ENTRY(mercury__graph__init_1_0));
	}
Define_label(mercury__graph__init_1_0_i4);
	update_prof_current_proc(LABEL(mercury__graph__init_1_0));
	r2 = (Integer) r1;
	tag_incr_hp(r1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r1, ((Integer) 0)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 1)) = ((Integer) 0);
	field(mktag(0), (Integer) r1, ((Integer) 2)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r1, ((Integer) 3)) = (Integer) detstackvar(2);
	field(mktag(0), (Integer) r1, ((Integer) 4)) = (Integer) r2;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(3);
	decr_sp_pop_msg(3);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__graph_module25)
	init_entry(mercury__graph__set_node_4_0);
BEGIN_CODE

/* code for predicate 'graph__set_node'/4 in mode 0 */
Define_entry(mercury__graph__set_node_4_0);
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury__graph__set_node__ua10000_4_0),
		ENTRY(mercury__graph__set_node_4_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module26)
	init_entry(mercury__graph__insert_node_4_0);
	init_label(mercury__graph__insert_node_4_0_i2);
	init_label(mercury__graph__insert_node_4_0_i1000);
BEGIN_CODE

/* code for predicate 'graph__insert_node'/4 in mode 0 */
Define_entry(mercury__graph__insert_node_4_0);
	incr_sp_push_msg(2, "graph__insert_node");
	detstackvar(2) = (Integer) succip;
	detstackvar(1) = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__graph__insert_node__ua0_4_0),
		mercury__graph__insert_node_4_0_i2,
		ENTRY(mercury__graph__insert_node_4_0));
Define_label(mercury__graph__insert_node_4_0_i2);
	update_prof_current_proc(LABEL(mercury__graph__insert_node_4_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(2);
	decr_sp_pop_msg(2);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__graph__insert_node_4_0_i1000);
	r1 = TRUE;
	proceed();
Define_label(mercury__graph__insert_node_4_0_i1000);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__graph_module27)
	init_entry(mercury__graph__det_insert_node_4_0);
BEGIN_CODE

/* code for predicate 'graph__det_insert_node'/4 in mode 0 */
Define_entry(mercury__graph__det_insert_node_4_0);
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury__graph__det_insert_node__ua10000_4_0),
		ENTRY(mercury__graph__det_insert_node_4_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module28)
	init_entry(mercury__graph__search_node_3_0);
	init_label(mercury__graph__search_node_3_0_i1);
BEGIN_CODE

/* code for predicate 'graph__search_node'/3 in mode 0 */
Define_entry(mercury__graph__search_node_3_0);
	{
	Declare_entry(do_fail);
	mkframe("graph__search_node/3", 1, ENTRY(do_fail));
	}
	framevar(0) = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	call_localret(STATIC(mercury__graph__search_node__ua40000_3_0),
		mercury__graph__search_node_3_0_i1,
		ENTRY(mercury__graph__search_node_3_0));
Define_label(mercury__graph__search_node_3_0_i1);
	update_prof_current_proc(LABEL(mercury__graph__search_node_3_0));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__graph_module29)
	init_entry(mercury__graph__find_matching_nodes_3_0);
BEGIN_CODE

/* code for predicate 'graph__find_matching_nodes'/3 in mode 0 */
Define_entry(mercury__graph__find_matching_nodes_3_0);
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury__graph__find_matching_nodes__ua10000_3_0),
		ENTRY(mercury__graph__find_matching_nodes_3_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module30)
	init_entry(mercury__graph__node_contents_3_0);
BEGIN_CODE

/* code for predicate 'graph__node_contents'/3 in mode 0 */
Define_entry(mercury__graph__node_contents_3_0);
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury__graph__node_contents__ua10000_3_0),
		ENTRY(mercury__graph__node_contents_3_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module31)
	init_entry(mercury__graph__successors_3_0);
BEGIN_CODE

/* code for predicate 'graph__successors'/3 in mode 0 */
Define_entry(mercury__graph__successors_3_0);
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	tailcall(STATIC(mercury__graph__successors__ua10000_3_0),
		ENTRY(mercury__graph__successors_3_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module32)
	init_entry(mercury__graph__nodes_2_0);
BEGIN_CODE

/* code for predicate 'graph__nodes'/2 in mode 0 */
Define_entry(mercury__graph__nodes_2_0);
	r2 = (Integer) r3;
	tailcall(STATIC(mercury__graph__nodes__ua10000_2_0),
		ENTRY(mercury__graph__nodes_2_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module33)
	init_entry(mercury__graph__set_edge_6_0);
	init_label(mercury__graph__set_edge_6_0_i2);
	init_label(mercury__graph__set_edge_6_0_i3);
	init_label(mercury__graph__set_edge_6_0_i4);
	init_label(mercury__graph__set_edge_6_0_i5);
BEGIN_CODE

/* code for predicate 'graph__set_edge'/6 in mode 0 */
Define_entry(mercury__graph__set_edge_6_0);
	r8 = (Integer) r1;
	incr_sp_push_msg(6, "graph__set_edge");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	r4 = ((Integer) field(mktag(0), (Integer) r3, ((Integer) 1)) + ((Integer) 1));
	detstackvar(3) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	r3 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) r3;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r9 = (Integer) r2;
	r11 = (Integer) r5;
	detstackvar(2) = (Integer) r5;
	detstackvar(4) = (Integer) tempr1;
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) r9;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r8;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_graph__base_type_info_arc_info_2;
	tag_incr_hp(r5, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) r11;
	field(mktag(0), (Integer) r5, ((Integer) 2)) = (Integer) r6;
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__graph__set_edge_6_0_i2,
		ENTRY(mercury__graph__set_edge_6_0));
	}
	}
Define_label(mercury__graph__set_edge_6_0_i2);
	update_prof_current_proc(LABEL(mercury__graph__set_edge_6_0));
	r2 = (Integer) detstackvar(4);
	r3 = (Integer) field(mktag(0), (Integer) r2, ((Integer) 4));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	detstackvar(4) = (Integer) tempr1;
	detstackvar(5) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) r1;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r2, ((Integer) 0));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__graph__set_edge_6_0_i3,
		ENTRY(mercury__graph__set_edge_6_0));
	}
	}
Define_label(mercury__graph__set_edge_6_0_i3);
	update_prof_current_proc(LABEL(mercury__graph__set_edge_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__graph__set_edge_6_0_i4,
		ENTRY(mercury__graph__set_edge_6_0));
	}
Define_label(mercury__graph__set_edge_6_0_i4);
	update_prof_current_proc(LABEL(mercury__graph__set_edge_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__graph__set_edge_6_0_i5,
		ENTRY(mercury__graph__set_edge_6_0));
	}
Define_label(mercury__graph__set_edge_6_0_i5);
	update_prof_current_proc(LABEL(mercury__graph__set_edge_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) detstackvar(3);
	tag_incr_hp(r2, mktag(0), ((Integer) 5));
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r2, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	field(mktag(0), (Integer) r2, ((Integer) 4)) = (Integer) r3;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module34)
	init_entry(mercury__graph__insert_edge_6_0);
	init_label(mercury__graph__insert_edge_6_0_i2);
	init_label(mercury__graph__insert_edge_6_0_i4);
	init_label(mercury__graph__insert_edge_6_0_i5);
	init_label(mercury__graph__insert_edge_6_0_i6);
	init_label(mercury__graph__insert_edge_6_0_i1);
BEGIN_CODE

/* code for predicate 'graph__insert_edge'/6 in mode 0 */
Define_entry(mercury__graph__insert_edge_6_0);
	r8 = (Integer) r1;
	incr_sp_push_msg(6, "graph__insert_edge");
	detstackvar(6) = (Integer) succip;
	detstackvar(1) = (Integer) r4;
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	r4 = ((Integer) field(mktag(0), (Integer) r3, ((Integer) 1)) + ((Integer) 1));
	detstackvar(3) = (Integer) r4;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r4;
	r3 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) r3;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r9 = (Integer) r2;
	r11 = (Integer) r5;
	detstackvar(2) = (Integer) r5;
	detstackvar(4) = (Integer) tempr1;
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) r9;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) r8;
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_graph__base_type_info_arc_info_2;
	tag_incr_hp(r5, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r5, ((Integer) 0)) = (Integer) detstackvar(1);
	field(mktag(0), (Integer) r5, ((Integer) 1)) = (Integer) r11;
	field(mktag(0), (Integer) r5, ((Integer) 2)) = (Integer) r6;
	{
	Declare_entry(mercury__map__insert_4_0);
	call_localret(ENTRY(mercury__map__insert_4_0),
		mercury__graph__insert_edge_6_0_i2,
		ENTRY(mercury__graph__insert_edge_6_0));
	}
	}
Define_label(mercury__graph__insert_edge_6_0_i2);
	update_prof_current_proc(LABEL(mercury__graph__insert_edge_6_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury__graph__insert_edge_6_0_i1);
	r1 = (Integer) detstackvar(4);
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 4));
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 5));
	detstackvar(4) = (Integer) tempr1;
	detstackvar(5) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 4)) = (Integer) r3;
	field(mktag(0), (Integer) tempr1, ((Integer) 3)) = (Integer) r2;
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__graph__insert_edge_6_0_i4,
		ENTRY(mercury__graph__insert_edge_6_0));
	}
	}
Define_label(mercury__graph__insert_edge_6_0_i4);
	update_prof_current_proc(LABEL(mercury__graph__insert_edge_6_0));
	r3 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mercury_data___base_type_info_int_0;
	r4 = (Integer) detstackvar(3);
	r5 = (Integer) detstackvar(2);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__graph__insert_edge_6_0_i5,
		ENTRY(mercury__graph__insert_edge_6_0));
	}
Define_label(mercury__graph__insert_edge_6_0_i5);
	update_prof_current_proc(LABEL(mercury__graph__insert_edge_6_0));
	r5 = (Integer) r1;
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	r3 = (Integer) detstackvar(5);
	r4 = (Integer) detstackvar(1);
	{
	Declare_entry(mercury__map__set_4_1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__graph__insert_edge_6_0_i6,
		ENTRY(mercury__graph__insert_edge_6_0));
	}
Define_label(mercury__graph__insert_edge_6_0_i6);
	update_prof_current_proc(LABEL(mercury__graph__insert_edge_6_0));
	r2 = (Integer) detstackvar(3);
	tag_incr_hp(r3, mktag(0), ((Integer) 5));
	field(mktag(0), (Integer) r3, ((Integer) 4)) = (Integer) r1;
	{
	Word tempr1;
	tempr1 = (Integer) detstackvar(4);
	field(mktag(0), (Integer) r3, ((Integer) 3)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 3));
	field(mktag(0), (Integer) r3, ((Integer) 2)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 2));
	field(mktag(0), (Integer) r3, ((Integer) 1)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 1));
	field(mktag(0), (Integer) r3, ((Integer) 0)) = (Integer) field(mktag(0), (Integer) tempr1, ((Integer) 0));
	r1 = TRUE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__graph__insert_edge_6_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(6);
	decr_sp_pop_msg(6);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__graph_module35)
	init_entry(mercury__graph__det_insert_edge_6_0);
	init_label(mercury__graph__det_insert_edge_6_0_i4);
	init_label(mercury__graph__det_insert_edge_6_0_i1000);
BEGIN_CODE

/* code for predicate 'graph__det_insert_edge'/6 in mode 0 */
Define_entry(mercury__graph__det_insert_edge_6_0);
	incr_sp_push_msg(1, "graph__det_insert_edge");
	detstackvar(1) = (Integer) succip;
	{
		call_localret(STATIC(mercury__graph__insert_edge_6_0),
		mercury__graph__det_insert_edge_6_0_i4,
		ENTRY(mercury__graph__det_insert_edge_6_0));
	}
Define_label(mercury__graph__det_insert_edge_6_0_i4);
	update_prof_current_proc(LABEL(mercury__graph__det_insert_edge_6_0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	if (!((Integer) r1))
		GOTO_LABEL(mercury__graph__det_insert_edge_6_0_i1000);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	proceed();
Define_label(mercury__graph__det_insert_edge_6_0_i1000);
	r1 = string_const("graph__det_insert_edge: this edge is already in the graph.", 58);
	{
	Declare_entry(mercury__require__error_1_0);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__graph__det_insert_edge_6_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module36)
	init_entry(mercury__graph__arc_contents_5_0);
	init_label(mercury__graph__arc_contents_5_0_i2);
BEGIN_CODE

/* code for predicate 'graph__arc_contents'/5 in mode 0 */
Define_entry(mercury__graph__arc_contents_5_0);
	{
	Word tempr1;
	tag_incr_hp(tempr1, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) tempr1, ((Integer) 2)) = (Integer) r2;
	r2 = (Integer) tempr1;
	field(mktag(0), (Integer) tempr1, ((Integer) 1)) = (Integer) r1;
	r3 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	field(mktag(0), (Integer) tempr1, ((Integer) 0)) = (Integer) mercury_data_graph__base_type_info_arc_info_2;
	incr_sp_push_msg(1, "graph__arc_contents");
	detstackvar(1) = (Integer) succip;
	{
	Declare_entry(mercury__map__lookup_3_1);
	call_localret(ENTRY(mercury__map__lookup_3_1),
		mercury__graph__arc_contents_5_0_i2,
		ENTRY(mercury__graph__arc_contents_5_0));
	}
	}
Define_label(mercury__graph__arc_contents_5_0_i2);
	update_prof_current_proc(LABEL(mercury__graph__arc_contents_5_0));
	r2 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 1));
	r3 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 2));
	r1 = (Integer) field(mktag(0), (Integer) r1, ((Integer) 0));
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(1);
	decr_sp_pop_msg(1);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__graph_module37)
	init_entry(mercury__graph__path_4_0);
	init_label(mercury__graph__path_4_0_i1);
BEGIN_CODE

/* code for predicate 'graph__path'/4 in mode 0 */
Define_entry(mercury__graph__path_4_0);
	{
	Declare_entry(do_fail);
	mkframe("graph__path/4", 2, ENTRY(do_fail));
	}
	framevar(0) = (Integer) r1;
	framevar(1) = (Integer) r2;
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	r3 = (Integer) r5;
	call_localret(STATIC(mercury__graph__path__ua40000_4_0),
		mercury__graph__path_4_0_i1,
		ENTRY(mercury__graph__path_4_0));
Define_label(mercury__graph__path_4_0_i1);
	update_prof_current_proc(LABEL(mercury__graph__path_4_0));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__graph_module38)
	init_entry(mercury__graph__path_4_1);
	init_label(mercury__graph__path_4_1_i1);
BEGIN_CODE

/* code for predicate 'graph__path'/4 in mode 1 */
Define_entry(mercury__graph__path_4_1);
	{
	Declare_entry(do_fail);
	mkframe("graph__path/4", 2, ENTRY(do_fail));
	}
	framevar(0) = (Integer) r1;
	framevar(1) = (Integer) r2;
	r1 = (Integer) r3;
	r2 = (Integer) r4;
	call_localret(STATIC(mercury__graph__path__ua40001_4_0),
		mercury__graph__path_4_1_i1,
		ENTRY(mercury__graph__path_4_1));
Define_label(mercury__graph__path_4_1_i1);
	update_prof_current_proc(LABEL(mercury__graph__path_4_1));
	succeed();
END_MODULE

BEGIN_MODULE(mercury__graph_module39)
	init_entry(mercury____Unify___graph__graph_2_0);
	init_label(mercury____Unify___graph__graph_2_0_i2);
	init_label(mercury____Unify___graph__graph_2_0_i4);
	init_label(mercury____Unify___graph__graph_2_0_i1005);
	init_label(mercury____Unify___graph__graph_2_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___graph__graph_2_0);
	if (((Integer) field(mktag(0), (Integer) r3, ((Integer) 0)) != (Integer) field(mktag(0), (Integer) r4, ((Integer) 0))))
		GOTO_LABEL(mercury____Unify___graph__graph_2_0_i1005);
	if (((Integer) field(mktag(0), (Integer) r3, ((Integer) 1)) != (Integer) field(mktag(0), (Integer) r4, ((Integer) 1))))
		GOTO_LABEL(mercury____Unify___graph__graph_2_0_i1005);
	incr_sp_push_msg(7, "__Unify__");
	detstackvar(7) = (Integer) succip;
	detstackvar(6) = (Integer) r2;
	r2 = (Integer) r1;
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 4));
	detstackvar(5) = (Integer) r1;
	r4 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 2));
	r3 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	r1 = (Integer) mercury_data___base_type_info_int_0;
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___graph__graph_2_0_i2,
		ENTRY(mercury____Unify___graph__graph_2_0));
	}
Define_label(mercury____Unify___graph__graph_2_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___graph__graph_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___graph__graph_2_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_graph__base_type_info_arc_info_2;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(5);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(6);
	r3 = (Integer) detstackvar(1);
	r4 = (Integer) detstackvar(3);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___graph__graph_2_0_i4,
		ENTRY(mercury____Unify___graph__graph_2_0));
	}
Define_label(mercury____Unify___graph__graph_2_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___graph__graph_2_0));
	if (!((Integer) r1))
		GOTO_LABEL(mercury____Unify___graph__graph_2_0_i1);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(4);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	{
	Declare_entry(mercury____Unify___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___graph__graph_2_0));
	}
Define_label(mercury____Unify___graph__graph_2_0_i1005);
	r1 = FALSE;
	proceed();
Define_label(mercury____Unify___graph__graph_2_0_i1);
	r1 = FALSE;
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(7);
	decr_sp_pop_msg(7);
	proceed();
END_MODULE

BEGIN_MODULE(mercury__graph_module40)
	init_entry(mercury____Index___graph__graph_2_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___graph__graph_2_0);
	tailcall(STATIC(mercury____Index___graph_graph_2__ua10000_2_0),
		ENTRY(mercury____Index___graph__graph_2_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module41)
	init_entry(mercury____Compare___graph__graph_2_0);
	init_label(mercury____Compare___graph__graph_2_0_i4);
	init_label(mercury____Compare___graph__graph_2_0_i5);
	init_label(mercury____Compare___graph__graph_2_0_i3);
	init_label(mercury____Compare___graph__graph_2_0_i10);
	init_label(mercury____Compare___graph__graph_2_0_i16);
	init_label(mercury____Compare___graph__graph_2_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___graph__graph_2_0);
	incr_sp_push_msg(11, "__Compare__");
	detstackvar(11) = (Integer) succip;
	detstackvar(9) = (Integer) r1;
	detstackvar(10) = (Integer) r2;
	r1 = (Integer) field(mktag(0), (Integer) r3, ((Integer) 0));
	detstackvar(1) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 1));
	detstackvar(2) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 2));
	detstackvar(3) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 3));
	detstackvar(4) = (Integer) field(mktag(0), (Integer) r3, ((Integer) 4));
	r2 = (Integer) field(mktag(0), (Integer) r4, ((Integer) 0));
	detstackvar(5) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 1));
	detstackvar(6) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 2));
	detstackvar(7) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 3));
	detstackvar(8) = (Integer) field(mktag(0), (Integer) r4, ((Integer) 4));
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___graph__graph_2_0_i4,
		ENTRY(mercury____Compare___graph__graph_2_0));
	}
Define_label(mercury____Compare___graph__graph_2_0_i4);
	update_prof_current_proc(LABEL(mercury____Compare___graph__graph_2_0));
	if (((Integer) r1 == ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___graph__graph_2_0_i3);
Define_label(mercury____Compare___graph__graph_2_0_i5);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Compare___graph__graph_2_0_i3);
	r1 = (Integer) detstackvar(1);
	r2 = (Integer) detstackvar(5);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___graph__graph_2_0_i10,
		ENTRY(mercury____Compare___graph__graph_2_0));
	}
Define_label(mercury____Compare___graph__graph_2_0_i10);
	update_prof_current_proc(LABEL(mercury____Compare___graph__graph_2_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___graph__graph_2_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) detstackvar(9);
	r3 = (Integer) detstackvar(2);
	r4 = (Integer) detstackvar(6);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___graph__graph_2_0_i16,
		ENTRY(mercury____Compare___graph__graph_2_0));
	}
Define_label(mercury____Compare___graph__graph_2_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___graph__graph_2_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___graph__graph_2_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	tag_incr_hp(r2, mktag(0), ((Integer) 3));
	field(mktag(0), (Integer) r2, ((Integer) 0)) = (Integer) mercury_data_graph__base_type_info_arc_info_2;
	field(mktag(0), (Integer) r2, ((Integer) 1)) = (Integer) detstackvar(9);
	field(mktag(0), (Integer) r2, ((Integer) 2)) = (Integer) detstackvar(10);
	r3 = (Integer) detstackvar(3);
	r4 = (Integer) detstackvar(7);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___graph__graph_2_0_i22,
		ENTRY(mercury____Compare___graph__graph_2_0));
	}
Define_label(mercury____Compare___graph__graph_2_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___graph__graph_2_0));
	if (((Integer) r1 != ((Integer) 0)))
		GOTO_LABEL(mercury____Compare___graph__graph_2_0_i5);
	r1 = (Integer) mercury_data___base_type_info_int_0;
	r2 = (Integer) mkword(mktag(0), (Integer) mercury_data_graph__common_0);
	r3 = (Integer) detstackvar(4);
	r4 = (Integer) detstackvar(8);
	LVALUE_CAST(Word,succip) = (Integer) detstackvar(11);
	decr_sp_pop_msg(11);
	{
	Declare_entry(mercury____Compare___tree234__tree234_2_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___graph__graph_2_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module42)
	init_entry(mercury____Unify___graph__node_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___graph__node_1_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury____Unify___graph_node_1__ua0_2_0),
		ENTRY(mercury____Unify___graph__node_1_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module43)
	init_entry(mercury____Index___graph__node_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___graph__node_1_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury____Index___graph_node_1__ua10000_2_0),
		ENTRY(mercury____Index___graph__node_1_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module44)
	init_entry(mercury____Compare___graph__node_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___graph__node_1_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury____Compare___graph_node_1__ua10000_3_0),
		ENTRY(mercury____Compare___graph__node_1_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module45)
	init_entry(mercury____Unify___graph__arc_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___graph__arc_1_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury____Unify___graph_arc_1__ua0_2_0),
		ENTRY(mercury____Unify___graph__arc_1_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module46)
	init_entry(mercury____Index___graph__arc_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___graph__arc_1_0);
	r1 = (Integer) r2;
	tailcall(STATIC(mercury____Index___graph_arc_1__ua10000_2_0),
		ENTRY(mercury____Index___graph__arc_1_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module47)
	init_entry(mercury____Compare___graph__arc_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___graph__arc_1_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	tailcall(STATIC(mercury____Compare___graph_arc_1__ua10000_3_0),
		ENTRY(mercury____Compare___graph__arc_1_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module48)
	init_entry(mercury____Unify___graph__graph_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___graph__graph_1_0);
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) mercury_data_std_util__base_type_info_unit_0;
	{
		tailcall(STATIC(mercury____Unify___graph__graph_2_0),
		ENTRY(mercury____Unify___graph__graph_1_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module49)
	init_entry(mercury____Index___graph__graph_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___graph__graph_1_0);
	tailcall(STATIC(mercury____Index___graph_graph_1__ua10000_2_0),
		ENTRY(mercury____Index___graph__graph_1_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module50)
	init_entry(mercury____Compare___graph__graph_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___graph__graph_1_0);
	r4 = (Integer) r3;
	r3 = (Integer) r2;
	r2 = (Integer) mercury_data_std_util__base_type_info_unit_0;
	{
		tailcall(STATIC(mercury____Compare___graph__graph_2_0),
		ENTRY(mercury____Compare___graph__graph_1_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module51)
	init_entry(mercury____Unify___graph__arc_0_0);
	init_label(mercury____Unify___graph__arc_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___graph__arc_0_0);
	if (((Integer) r1 != (Integer) r2))
		GOTO_LABEL(mercury____Unify___graph__arc_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___graph__arc_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

BEGIN_MODULE(mercury__graph_module52)
	init_entry(mercury____Index___graph__arc_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___graph__arc_0_0);
	{
	Declare_entry(mercury__builtin_index_int_2_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___graph__arc_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module53)
	init_entry(mercury____Compare___graph__arc_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___graph__arc_0_0);
	{
	Declare_entry(mercury__builtin_compare_int_3_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___graph__arc_0_0));
	}
END_MODULE

BEGIN_MODULE(mercury__graph_module54)
	init_entry(mercury____Unify___graph__arc_info_2_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___graph__arc_info_2_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury____Unify___graph_arc_info_2__ua0_2_0),
		STATIC(mercury____Unify___graph__arc_info_2_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module55)
	init_entry(mercury____Index___graph__arc_info_2_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___graph__arc_info_2_0);
	tailcall(STATIC(mercury____Index___graph_arc_info_2__ua10000_2_0),
		STATIC(mercury____Index___graph__arc_info_2_0));
END_MODULE

BEGIN_MODULE(mercury__graph_module56)
	init_entry(mercury____Compare___graph__arc_info_2_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___graph__arc_info_2_0);
	r1 = (Integer) r2;
	r2 = (Integer) r3;
	r3 = (Integer) r4;
	tailcall(STATIC(mercury____Compare___graph_arc_info_2__ua10000_3_0),
		STATIC(mercury____Compare___graph__arc_info_2_0));
END_MODULE

#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

static void mercury__graph_bunch_0(void)
{
	mercury__graph_module0();
	mercury__graph_module1();
	mercury__graph_module2();
	mercury__graph_module3();
	mercury__graph_module4();
	mercury__graph_module5();
	mercury__graph_module6();
	mercury__graph_module7();
	mercury__graph_module8();
	mercury__graph_module9();
	mercury__graph_module10();
	mercury__graph_module11();
	mercury__graph_module12();
	mercury__graph_module13();
	mercury__graph_module14();
	mercury__graph_module15();
	mercury__graph_module16();
	mercury__graph_module17();
	mercury__graph_module18();
	mercury__graph_module19();
	mercury__graph_module20();
	mercury__graph_module21();
	mercury__graph_module22();
	mercury__graph_module23();
	mercury__graph_module24();
	mercury__graph_module25();
	mercury__graph_module26();
	mercury__graph_module27();
	mercury__graph_module28();
	mercury__graph_module29();
	mercury__graph_module30();
	mercury__graph_module31();
	mercury__graph_module32();
	mercury__graph_module33();
	mercury__graph_module34();
	mercury__graph_module35();
	mercury__graph_module36();
	mercury__graph_module37();
	mercury__graph_module38();
	mercury__graph_module39();
	mercury__graph_module40();
}

static void mercury__graph_bunch_1(void)
{
	mercury__graph_module41();
	mercury__graph_module42();
	mercury__graph_module43();
	mercury__graph_module44();
	mercury__graph_module45();
	mercury__graph_module46();
	mercury__graph_module47();
	mercury__graph_module48();
	mercury__graph_module49();
	mercury__graph_module50();
	mercury__graph_module51();
	mercury__graph_module52();
	mercury__graph_module53();
	mercury__graph_module54();
	mercury__graph_module55();
	mercury__graph_module56();
}

#endif

void mercury__graph__init(void); /* suppress gcc warning */
void mercury__graph__init(void)
{
#if (defined(USE_GCC_NONLOCAL_GOTOS) && !defined(USE_ASM_LABELS)) \
	|| defined(PROFILE_CALLS) || defined(DEBUG_GOTOS) \
	|| defined(DEBUG_LABELS) || !defined(SPEED) \
	|| defined(NATIVE_GC) 

	mercury__graph_bunch_0();
	mercury__graph_bunch_1();
#endif
}
