#!/usr/bin/perl
#
#

print "Content-type: text/html\n\n";

#
# standard-coverpage
#
$scoverpage="/coverpage";

#
# faxspool
#
$faxspool="/usr/local/bin/faxspool";

$time=`/bin/date`;

$query_string=$ENV{'QUERY_STRING'};

# Auswerten der Argumentzeilen
%args=();
foreach (split(/\&/,$query_string))
{
	if ( /^(\w+)=/ && ($key=$1) && ($value=$') )
	{
		$value =~ s/\+/ /go;
		$value =~ s/\%([0-9a-f]{2})/pack(C,hex($1))/eig;
		if ( $key eq "BEST" )
		{
			($to_name, $from_name, $mailto, $to_number, $message, $addocuments, $coverpage, $coverp) = split(/\|/, $value);
		}

		$args{"$key"}=$args{"$key"} . " " . $value if ($value!~/^\s*$/);
		$args{"$key"} =~ s/^\s*//o;
	}
}

print "$args{\"Typ\"}\n";

# **************************************************************************
print "<html><head><title>\n";
print "Send short fax\n";
print "</title>";
print "<h1><center>";
print "<img src=\"/mgetty+sendfax/pics/m+slogo2.gif\" ALT=\"mgetty+sendfax\" width=50%>";
print "</center><p>";
print "<img src=\"/mgetty+sendfax/pics/hline.gif\"";
print "ALT=\"-------------------------------------------------------------\"";
print "width=100%>";
print "</h1>";
print "</head><body>";
print "<h2><center>";
print "send short fax";
print "</center></h2>";
print "<hr>";
print "<h3>";
print "your fax will be send<p>"; 
print "<dt><dd>TO: ";
# **********************************************************************

print "$args{to_name} ($args{to_number})\n";
print "<dd>FROM: ";
print "$args{from_name} \n";
print "<p>";
print "</dt><p><hr>\n";
print "The message to send is:<p>";
print "$args{message}";
if ($args{addocuments} == "")
	{
	print "<p>nothing will be added";
	}
else
	{
	print "<p>$args{addocuments} will be added";
	}
print "<p><br><br>\n";
print "used coverpage: ";

if ( $args{coverp} == 0)
	{
	print "$scoverpage \n";
	}
elsif ( $args{coverp} == 1)
	{
	print "none... \n";
	}
elsif ( $args{coverp} == 2)
	{
	print "$args{coverpage}\n";
	}
else
	{
	print "ERROR - no value for Coverpage!\n";
	}

$memo='/tmp/shortmsg';

open (MEMO, "> $memo");
print MEMO "$args{message}";
close MEMO;
$|=1;
print "<pre>";

 if ($args{coverp} == 0)
 	{
 system "$faxspool \-f $args{mailto} \-C $scoverpage \-D \"$args{to_name}\" \-F $args{from_name} $args{to_number} $memo $args{addocuments} 2>&1";
 	}
 elsif ($args{coverp} == 1)
	{
 system "$faxspool \-f $args{mailto} \-D \"$args{to_name}\" \-F $args{from_name} $args{to_number} $memo $args{addocuments} 2>&1";
	}
 else
 	{
 system "$faxspool \-f $args{mailto} \-C $args{coverpage} \-D \"$args{to_name}\" \-F $args{from_name} $args{to_number} $memo $args{addocuments} 2>&1";
	}

print "</pre>";

# ******************** Fuss ********************************************
print "</h3>";
print "<img src=\"/mgetty+sendfax/pics/hline.gif\"";
print "ALT=\"-------------------------------------------------------------\"";
print "width=100%>";
print "</body>";
print "<address>";
print "mgetty+sendfax by <a href=\"http://greenie.muc.de/~gert\">Gert D&ouml;ring</a>\n";
print "<br>Pages by <a href=\"http://greenie.muc.de/~neko/\">Simone";
print "Demmel</a> \(<a href=\"mailto:neko\@greenie.muc.de\">NEKO</a>\)";
print "<br>$time\n";
print "</address>";
print "</body>";
print "</html>";
# *********************************************************************


exit 0
