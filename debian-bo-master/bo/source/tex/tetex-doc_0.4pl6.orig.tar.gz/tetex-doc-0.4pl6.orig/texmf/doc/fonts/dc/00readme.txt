% 00readme.txt
%
% (c) Copyright 1995 J"org Knappen
% (c) Copyright 1990, 1992 Norbert Schwarz
%
% This file is part of dcfonts version 1.2
%
% Please read the files 00readme.txt, 00inst.txt, 00error.txt, and
% copyrite.txt for further information
%
% You find some documentation in dcdoc.tex (needs LaTeX2e)
%
    European Computer Modern Fonts and Text Companion Fonts

This is release 1.2 of the dc fonts, which are still in their test phase.
Nothing, except the encoding of the fonts, is frozen yet, and there may
be changes without prior announcement.

Please read the copying condition as given in the file copyrite.txt.

For installation, please read the file 00inst.txt.

If you find a problem or a bug, please read the file 00error.txt
before submitting a bug report. The address for submitting bug
reports is knappen@vkpmzd.kph.uni-mainz.de

--J"org Knappen.

